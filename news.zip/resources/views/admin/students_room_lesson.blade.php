@extends('admin.layouts.v2')

@section('page_title', 'علامات طلاب الشعبة')
@section('page_subtitle', 'إدارة العلامات والتقييمات الخاصة بالمادة')
@section('style')
<style>
    .students-room-lesson-v2 { direction: rtl; text-align: right; }
    /* ── Breadcrumbs ── */
    .v2-bc { display:flex; align-items:center; gap:.4rem; font-size:.9rem; flex-wrap:wrap; direction:rtl; }
    .v2-bc a { color:#8a869a; font-weight:700; text-decoration:none; }
    .v2-bc a:hover { color:#5B4B8A; }
    .v2-bc .sep { color:#b2aec0; font-weight:700; }
    .v2-bc .active { color:#2f2b3a; font-weight:700; }

    /* ── Outer card wrapper ── */
    .v2-section-card {
        border-radius: 18px;
        border: 1px solid rgba(91,75,138,0.12);
        box-shadow: 0 12px 32px rgba(36,30,62,0.08);
        background: #fff;
        overflow: hidden;
    }
    .students-room-lesson-card {
        margin: 1.25rem;
        padding: 1.5rem;
    }
    .lesson-page-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        flex-wrap: wrap;
        margin-bottom: 1.25rem;
    }
    .lesson-page-toolbar__title h2 {
        margin: 0;
        color: #2f2b3a;
        font-size: 1.35rem;
        font-weight: 800;
    }
    .lesson-page-toolbar__title p {
        margin: .35rem 0 0;
        color: #7a748f;
        font-size: .92rem;
        font-weight: 700;
    }
    .lesson-page-toolbar__actions {
        display: flex;
        align-items: center;
        gap: .75rem;
        flex-wrap: wrap;
    }
    .lesson-action-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 42px;
        padding: .65rem 1rem;
        border-radius: 12px;
        background: linear-gradient(135deg, #2c71ad, #84a7c4);
        color: #fff !important;
        font-weight: 700;
        font-size: .88rem;
        text-decoration: none !important;
        box-shadow: 0 10px 20px rgba(44,113,173,.15);
    }

    /* ── Grade table (kept as-is, only cosmetic override) ── */
    .students-room-lesson-v2 table {
        width: 100%;
        border-collapse: collapse;
        direction: rtl;
        text-align: right;
        background: #fff;
    }
    .students-room-lesson-v2 tr:nth-of-type(odd) { background: #fbfaff; }
    .students-room-lesson-v2 th {
        background: #f5f3fb !important;
        color: #2f2b3a !important;
        font-weight: 700;
        font-size: .88rem;
    }
    .students-room-lesson-v2 td, .students-room-lesson-v2 th { padding: 10px 8px; border: 1px solid rgba(91,75,138,0.12); text-align: right; vertical-align: middle; }

    @media only screen and (max-width: 760px),
    (min-device-width: 768px) and (max-device-width: 1024px) {
        .students-room-lesson-v2 table, .students-room-lesson-v2 thead, .students-room-lesson-v2 tbody, .students-room-lesson-v2 th, .students-room-lesson-v2 td, .students-room-lesson-v2 tr { display: block; }
        .students-room-lesson-v2 thead tr { position: absolute; top: -9999px; left: -9999px; }
        .students-room-lesson-v2 tr { border: 1px solid rgba(91,75,138,0.12); }
        .students-room-lesson-v2 td { border: none; border-bottom: 1px solid #eee; position: relative; padding-left: 50%; }
        .students-room-lesson-v2 td:before { position: absolute; top: 6px; left: 6px; width: 45%; padding-right: 10px; white-space: nowrap; }
        .students-room-lesson-v2 td:nth-of-type(1):before { content: "المواد الدراسية "; }
        .students-room-lesson-v2 td:nth-of-type(2):before { content: "الدرجة العظمى "; }
        .students-room-lesson-v2 td:nth-of-type(3):before { content: "درجات أعمال الفصل الأول "; }
        .students-room-lesson-v2 td:nth-of-type(4):before { content: "شفوية "; }
        .students-room-lesson-v2 td:nth-of-type(5):before { content: "وظائف وأوراق عمل "; }
        .students-room-lesson-v2 td:nth-of-type(6):before { content: "نشاطات ومبادرات "; }
        .students-room-lesson-v2 td:nth-of-type(7):before { content: "المذاكرات "; }
        .students-room-lesson-v2 td:nth-of-type(8):before { content: "درجة اختبار الفصل الأول "; }
        .students-room-lesson-v2 td:nth-of-type(9):before { content: "مجموع درجات الفصل الأول "; }
        .students-room-lesson-v2 td:nth-of-type(10):before { content: "تقدير الفصل الأول "; }
    }

    /* ── Tab system (unchanged) ── */
    .students-room-lesson-v2 .tabs {
        position: relative;
        background: transparent;
        padding: 0;
        width: 100%;
        border-radius: 0;
        min-width: 240px;
        direction: rtl;
        left: auto;
        transform: none;
    }
    .students-room-lesson-v2 .tabs input[name="tab-control"] { display: none; }
    .students-room-lesson-v2 .tabs .content section h2,
    .students-room-lesson-v2 .tabs ul li label {
        font-family: inherit;
        font-weight: 800;
        font-size: 1rem;
        color: #5B4B8A;
    }
    .students-room-lesson-v2 .tabs ul {
        list-style-type: none;
        padding-left: 0;
        flex-direction: row;
        margin-bottom: 1rem;
        display: flex;
        justify-content: flex-start;
        align-items: center;
        flex-wrap: wrap;
        gap: .75rem;
    }
    .students-room-lesson-v2 .tabs ul li { box-sizing: border-box; text-align: center; }
    .students-room-lesson-v2 .tabs ul li label {
        transition: all .3s ease-in-out;
        color: #7a748f;
        padding: .8rem 1.2rem;
        overflow: hidden;
        text-overflow: ellipsis;
        display: inline-flex;
        align-items: center;
        gap: .4rem;
        cursor: pointer;
        white-space: nowrap;
        border-radius: 999px;
        background: #f7f5fc;
        -webkit-touch-callout: none;
    }
    .students-room-lesson-v2 .tabs ul li label br { display: none; }
    .students-room-lesson-v2 .tabs ul li label svg { fill: #7a748f; height: 1.05em; vertical-align: bottom; margin-right: 0; transition: all .2s ease-in-out; }
    .students-room-lesson-v2 .tabs ul li label:hover,
    .students-room-lesson-v2 .tabs ul li label:focus,
    .students-room-lesson-v2 .tabs ul li label:active { outline: 0; color: #5B4B8A; }
    .students-room-lesson-v2 .tabs ul li label:hover svg,
    .students-room-lesson-v2 .tabs ul li label:focus svg,
    .students-room-lesson-v2 .tabs ul li label:active svg { fill: #5B4B8A; }
    .students-room-lesson-v2 .tabs .slider { display: none; }
    .students-room-lesson-v2 .tabs .content { margin-top: 1rem; }
    .students-room-lesson-v2 .tabs .content section {
        display: none;
        animation-name: content;
        animation-direction: normal;
        animation-duration: .3s;
        animation-timing-function: ease-in-out;
        animation-iteration-count: 1;
        line-height: 1.4;
        background: #fff;
        border: 1px solid rgba(91,75,138,0.12);
        border-radius: 18px;
        padding: 1rem;
        overflow-x: auto;
    }
    .students-room-lesson-v2 .tabs .content section h2 { color: #5B4B8A; display: none; }
    .students-room-lesson-v2 .tabs .content section h2::after { content: ""; position: relative; display: block; width: 30px; height: 3px; background: #f38639; margin-top: 5px; left: 1px; }
    .students-room-lesson-v2 .tabs input[name="tab-control"]:nth-of-type(1):checked~ul>li:nth-child(1)>label { cursor: default; color: #fff; background: linear-gradient(135deg, #5B4B8A, #7B67B2); }
    .students-room-lesson-v2 .tabs input[name="tab-control"]:nth-of-type(1):checked~ul>li:nth-child(1)>label svg { fill: #fff; }
    .students-room-lesson-v2 .tabs input[name="tab-control"]:nth-of-type(1):checked~.content>section:nth-child(1) { display: block; }
    .students-room-lesson-v2 .tabs input[name="tab-control"]:nth-of-type(2):checked~ul>li:nth-child(2)>label { cursor: default; color: #fff; background: linear-gradient(135deg, #5B4B8A, #7B67B2); }
    .students-room-lesson-v2 .tabs input[name="tab-control"]:nth-of-type(2):checked~ul>li:nth-child(2)>label svg { fill: #fff; }
    .students-room-lesson-v2 .tabs input[name="tab-control"]:nth-of-type(2):checked~.content>section:nth-child(2) { display: block; }
    .students-room-lesson-v2 .tabs input[name="tab-control"]:nth-of-type(3):checked~ul>li:nth-child(3)>label { cursor: default; color: #fff; background: linear-gradient(135deg, #5B4B8A, #7B67B2); }
    .students-room-lesson-v2 .tabs input[name="tab-control"]:nth-of-type(3):checked~ul>li:nth-child(3)>label svg { fill: #fff; }
    .students-room-lesson-v2 .tabs input[name="tab-control"]:nth-of-type(3):checked~.content>section:nth-child(3) { display: block; }
    @keyframes content { from { opacity: 0; transform: translateY(5%); } to { opacity: 1; transform: translateY(0%); } }
    @media (max-width: 600px) {
        .students-room-lesson-v2 .tabs ul li label { padding: .7rem .9rem; border-radius: 999px; }
        .students-room-lesson-v2 .tabs ul li label span { display: inline; }
        .students-room-lesson-v2 .tabs .content { margin-top: 20px; }
        .students-room-lesson-v2 .tabs .content section h2 { display: block; }
        .lesson-page-toolbar { align-items: flex-start; }
    }

    /* ── Floating mark input ── */
    .students-room-lesson-v2 .form__group { direction: rtl; position: relative; padding: 15px 0 0; margin-top: 10px; width: 20%; }
    .students-room-lesson-v2 .form__field { font-family: inherit; width: 150px; border: 0; border-bottom: 2px solid #9b9b9b; outline: 0; font-size: 1.3rem; color: #2c71ad; padding: 7px 0; background: transparent; transition: border-color .2s; }
    .students-room-lesson-v2 .form__field::placeholder { color: transparent; }
    .students-room-lesson-v2 .form__field:placeholder-shown~.form__label { font-size: 1.3rem; cursor: text; top: 20px; padding-right: 32px; }
    .students-room-lesson-v2 .form__label { text-align: right; position: absolute; top: 0; display: block; transition: .2s; font-size: 1rem; color: #9b9b9b; padding-right: 39px; }
    .students-room-lesson-v2 .form__field:focus { padding-bottom: 6px; font-weight: 700; border-width: 3px; }
    .students-room-lesson-v2 .form__field:focus~.form__label { position: absolute; top: 0; display: block; transition: .2s; font-size: 1rem; color: #11998e; font-weight: 700; }
    .students-room-lesson-v2 .form__field:required, .students-room-lesson-v2 .form__field:invalid { box-shadow: none; }
    .students-room-lesson-v2 input.number {
        width: 72px !important;
        height: 44px !important;
        border-radius: 10px;
        padding: .35rem !important;
        text-align: center;
        margin: 0 auto;
        display: block;
        font-weight: 700;
    }

    /* ── Modal ── */
    .modal .modal-content { border-radius:16px; overflow:hidden; direction:rtl; text-align:right; box-shadow:0 20px 60px rgba(0,0,0,.18); }
    .modal .modal-header { padding:1rem 1.5rem; border-bottom:1px solid #e9ecef; align-items:center; }
    .modal .modal-header h4, .modal .modal-title { font-size:1rem; font-weight:700; color:#2f2b3a; margin:0; }
    .modal .modal-body { padding:1.5rem; }
    .modal .form-control { border-radius:8px; border-color:#d0d5dd; }
    .modal .modal-footer { padding:1rem 1.5rem; border-top:1px solid #e9ecef; display:flex; flex-wrap:wrap; gap:.5rem; justify-content:flex-start; }
    .modal .modal-footer .btn { min-height:40px; min-width:100px; font-weight:600; border-radius:10px; }

    /* ── Misc ── */
    button.close { margin:0 !important; padding:0 !important; }
</style>
@endsection



@section('breadcrumbs')
<nav class="v2-bc" aria-label="Breadcrumb">
    <a href="{{ route('dashboard.index') }}">لوحة التحكم</a>
    <span class="sep">/</span>
    <a href="{{ route('classes') }}">قسم الصفوف</a>
    <span class="sep">/</span>
    <a href="{{ route('classroom',$room->class_id) }}">الشعب</a>
    <span class="sep">/</span>
    <a href="{{ route('roomlessons',[$room->class_id,$room->id]) }}">جدول مواد الشعبة</a>
    <span class="sep">/</span>
    <span class="active">طلاب الشعبة</span>
</nav>
@endsection


@section('content')

<div class="students-room-lesson-v2">
    <div class="v2-section-card students-room-lesson-card">

        <input type="hidden" name="count" id="count" value="{{ $count }}">
        <!-- Card header -->
        <!--    @if(session()->has('success'))-->
        <!--    <div class="alert alert-success text-center"  style="font-size: 20px">-->
        <!--         {{ session()->get('success') }}-->
        <!--    </div>-->
        <!--@endif-->

        @auth('web')



        @endauth
        @php
        function arabic_w2e($str)
        {
        $arabic_eastern = array('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩');
        $arabic_western = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
        return str_replace($arabic_western, $arabic_eastern, $str);
        }

        @endphp
        
        <div class="lesson-page-toolbar">
            <div class="lesson-page-toolbar__title">
                <h2>{{ $lesson->name }}</h2>
                <p>إدارة علامات الطلاب والتقييمات الخاصة بهذه المادة داخل الشعبة الحالية.</p>
            </div>
            <div class="lesson-page-toolbar__actions">
                @can('edit_student_marks')
                <a href=".deleteEmployeeModal11" class="lesson-action-btn" data-toggle="modal">
                    إضافة علامة للكل
                </a>
                <a href=".add_mark" class="lesson-action-btn" data-toggle="modal">
                    إضافة علامة تفصيلية للكل
                </a>
                @endcan
                @can('Download_excel_for_tags')
                <a href="{{ route('StudentsRoomLesson_excel',[$room->id,$lesson_id]) }}" target="_blank"
                    class="lesson-action-btn">
                    تنزيل إكسل
                </a>
                @endcan
            </div>
        </div>

        <div class="tabs">

            <input type="radio" id="tab1" name="tab-control" checked>
            <input type="radio" id="tab2" name="tab-control">
            <input type="radio" id="tab3" name="tab-control">

            <ul>
                <li title="الفصل الأول "><label for="tab1" role="button"><svg viewBox="0 0 24 24">
                            <path
                                d="M14,2A8,8 0 0,0 6,10A8,8 0 0,0 14,18A8,8 0 0,0 22,10H20C20,13.32 17.32,16 14,16A6,6 0 0,1 8,10A6,6 0 0,1 14,4C14.43,4 14.86,4.05 15.27,4.14L16.88,2.54C15.96,2.18 15,2 14,2M20.59,3.58L14,10.17L11.62,7.79L10.21,9.21L14,13L22,5M4.93,5.82C3.08,7.34 2,9.61 2,12A8,8 0 0,0 10,20C10.64,20 11.27,19.92 11.88,19.77C10.12,19.38 8.5,18.5 7.17,17.29C5.22,16.25 4,14.21 4,12C4,11.7 4.03,11.41 4.07,11.11C4.03,10.74 4,10.37 4,10C4,8.56 4.32,7.13 4.93,5.82Z" />
                        </svg>
                        <span>الفصل الأول</span></label></li> &nbsp;&nbsp;&nbsp;&nbsp;

                <li title="الفصل الثاني "><label for="tab2" role="button"><br><svg viewBox="0 0 24 24">
                            <path
                                d="M14,2A8,8 0 0,0 6,10A8,8 0 0,0 14,18A8,8 0 0,0 22,10H20C20,13.32 17.32,16 14,16A6,6 0 0,1 8,10A6,6 0 0,1 14,4C14.43,4 14.86,4.05 15.27,4.14L16.88,2.54C15.96,2.18 15,2 14,2M20.59,3.58L14,10.17L11.62,7.79L10.21,9.21L14,13L22,5M4.93,5.82C3.08,7.34 2,9.61 2,12A8,8 0 0,0 10,20C10.64,20 11.27,19.92 11.88,19.77C10.12,19.38 8.5,18.5 7.17,17.29C5.22,16.25 4,14.21 4,12C4,11.7 4.03,11.41 4.07,11.11C4.03,10.74 4,10.37 4,10C4,8.56 4.32,7.13 4.93,5.82Z" />
                        </svg>
                        <span>الفصل الثاني</span></label></li>&nbsp;&nbsp;&nbsp;&nbsp;

                <!--li title="المحصلة "><label for="tab3" role="button"><br><svg viewBox="0 0 24 24"><path d="M14,2A8,8 0 0,0 6,10A8,8 0 0,0 14,18A8,8 0 0,0 22,10H20C20,13.32 17.32,16 14,16A6,6 0 0,1 8,10A6,6 0 0,1 14,4C14.43,4 14.86,4.05 15.27,4.14L16.88,2.54C15.96,2.18 15,2 14,2M20.59,3.58L14,10.17L11.62,7.79L10.21,9.21L14,13L22,5M4.93,5.82C3.08,7.34 2,9.61 2,12A8,8 0 0,0 10,20C10.64,20 11.27,19.92 11.88,19.77C10.12,19.38 8.5,18.5 7.17,17.29C5.22,16.25 4,14.21 4,12C4,11.7 4.03,11.41 4.07,11.11C4.03,10.74 4,10.37 4,10C4,8.56 4.32,7.13 4.93,5.82Z"/>
          </svg>
            <span>المحصلة</span></label></li-->

            </ul>


            <div class="">
                <div class="indicator"></div>
            </div>

            <div class="content">
                <section>
                    <h2>الفصل الأول</h2>
                    <table>
                        <thead>
                            <tr>
                                <th rowspan="2" style="text-align: center;">الطلاب </th>
                                <th rowspan="2" style="text-align: center;">الدرجة العظمى </th>
                                <th rowspan="1" colspan="4" style="text-align: center;">درجات اعمال الفصل الأول </th>
                                <th rowspan="1" colspan="1" style="text-align: center;">درجة اختبار الفصل الأول </th>
                                <th rowspan="1" colspan="1" style="text-align: center;">مجموع درجات الفصل الأول </th>
                                <th rowspan="2" colspan="1" style="text-align: center;"> تقدير الفصل الأول </th>
                                <th rowspan="2" colspan="1" style="text-align: center;"> ارسال </th>

                            </tr>
                            <tr>

                                <th rowspan="1" colspan="1" style="text-align: center;">شفوية <br> <span
                                        style="color: #f38639;">%١٠</span> </th>
                                <th rowspan="1" colspan="1" style="text-align: center;"> وظائف و اوراق عمل <br> <span
                                        style="color: #f38639;">%١٠</span> </th>
                                <th rowspan="1" colspan="1" style="text-align: center;"> نشاطات و مبادرات <br> <span
                                        style="color: #f38639;">%٢٠</span></th>
                                <th rowspan="1" colspan="1" style="text-align: center;"> المذاكرات <br> <span
                                        style="color: #f38639;">%٢٠</span></th>
                                <th rowspan="1" colspan="1" style="text-align: center;"><span
                                        style="color: #f38639;">%٤٠</span>
                                </th>
                                <th rowspan="1" colspan="1" style="text-align:center;"><span
                                        style="color: #f38639;">%١٠٠</span>
                                </th>
                            </tr>


                        </thead>
                        <tbody>

                            @if ($students)
                            @foreach ( $students->student as $item )
                            <form action="{{ route('student_mark') }}" method="post">
                                @csrf
                                <tr>
                                    <input type="hidden" name="term" value="term1">
                                    <input type="hidden" name="room_id" value="{{ $room_id }}">
                                    <input type="hidden" name="student_id" value="{{$item->id}}">
                                    <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
                                    <td> {{ $item->first_name }} {{ $item->last_name }} </td>
                                    <td class="total" data-number="{{$lesson->max_mark	}}"> {{arabic_w2e($lesson->max_mark)	}} </td>

                                    @foreach ($item->student_mark as $item2)

                                    <td>
                                        @php
                                        $decodedData = json_decode($item2->mark);
                                      @endphp
                                        @if (!$decodedData ||  (!property_exists($decodedData,  $lesson_id )) )
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="" name="oral" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.1}}"
                                            max="{{$lesson->max_mark*0.1}}">

                                        @endif
                                        @foreach( json_decode($item2->mark,true) as $key=>$item)



                                        @if($key == $lesson_id && $item['oral'] !="null" )

                                        @if(json_decode($item2->mark,true)[$lesson_id]['oral'] == null)
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="{{ json_decode($item2->mark,true)[$lesson_id]['oral']}}" name="oral"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.1}}" max="{{$lesson->max_mark*0.1}}">
                                        @else
                                        <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                            value="{{ json_decode($item2->mark,true)[$lesson_id]['oral']}}" name="oral"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.1}}" max="{{$lesson->max_mark*0.1}}">
                                        @endif
                                        @break

                                        @endif

                                        @endforeach




                                    </td>


                                    <td>
                                        @php
                                        $decodedData = json_decode($item2->mark);
                                      @endphp
                                        @if (!$decodedData ||  (!property_exists($decodedData,  $lesson_id )) )
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="" name="homework" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.1}}"
                                            max="{{$lesson->max_mark*0.1}}">

                                        @endif

                                        @foreach( json_decode($item2->mark,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['homework'] !="null" )
                                        @if(json_decode($item2->mark,true)[$lesson_id]['homework'] == null)
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="{{ json_decode($item2->mark,true)[$lesson_id]['homework']}}"
                                            name="homework" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.1}}"
                                            max="{{$lesson->max_mark*0.1}}">
                                        @else
                                        <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                            value="{{ json_decode($item2->mark,true)[$lesson_id]['homework']}}"
                                            name="homework" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.1}}"
                                            max="{{$lesson->max_mark*0.1}}">
                                        @endif
                                        @break

                                        @endif

                                        @endforeach


                                    </td>

                                    <td>
                                        @php
                                        $decodedData = json_decode($item2->mark);
                                      @endphp
                                        @if (!$decodedData ||  (!property_exists($decodedData,  $lesson_id )) )
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="" name="activities" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.2}}"
                                            max="{{$lesson->max_mark*0.2}}">

                                        @endif
                                        @foreach( json_decode($item2->mark,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['activities'] !="null" )
                                        @if(json_decode($item2->mark,true)[$lesson_id]['activities'] == null)
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="{{ json_decode($item2->mark,true)[$lesson_id]['activities']}}"
                                            name="activities" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.2}}"
                                            max="{{$lesson->max_mark*0.2}}">
                                        @else
                                        <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                            value="{{ json_decode($item2->mark,true)[$lesson_id]['activities']}}"
                                            name="activities" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.2}}"
                                            max="{{$lesson->max_mark*0.2}}">
                                        @endif
                                        @break

                                        @endif

                                        @endforeach


                                    </td>

                                    <td>
                                        @php
                                        $decodedData = json_decode($item2->mark);
                                      @endphp
                                        @if (!$decodedData ||  (!property_exists($decodedData,  $lesson_id )) )
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="" name="quize" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.2}}"
                                            max="{{$lesson->max_mark*0.2}}">

                                        @endif
                                        @foreach( json_decode($item2->mark,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['quize'] !="null" )
                                        @if(json_decode($item2->mark,true)[$lesson_id]['quize'] == null)
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="{{ json_decode($item2->mark,true)[$lesson_id]['quize']}}"
                                            name="quize" onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.2}}" max="{{$lesson->max_mark*0.2}}">
                                        @else
                                        <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                            value="{{ json_decode($item2->mark,true)[$lesson_id]['quize']}}"
                                            name="quize" onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.2}}" max="{{$lesson->max_mark*0.2}}">
                                        @endif
                                        @break

                                        @endif

                                        @endforeach



                                    </td>

                                    <td>
                                        @php
                                        $decodedData = json_decode($item2->mark);
                                      @endphp
                                        @if (!$decodedData ||  (!property_exists($decodedData,  $lesson_id )) )
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="" name="exam" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.4}}"
                                            max="{{$lesson->max_mark*0.4}}">

                                        @endif
                                        @foreach( json_decode($item2->mark,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['exam'] !="null" )
                                        @if(json_decode($item2->mark,true)[$lesson_id]['exam'] == null)
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="{{ json_decode($item2->mark,true)[$lesson_id]['exam']}}" name="exam"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.4}}" max="{{$lesson->max_mark*0.4}}">
                                        @else
                                        <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                            value="{{ json_decode($item2->mark,true)[$lesson_id]['exam']}}" name="exam"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.4}}" max="{{$lesson->max_mark*0.4}}">
                                        @endif
                                        @break

                                        @endif

                                        @endforeach


                                    </td>
                                    <td>
                                        @if($item2->result1)
                                        @foreach( json_decode($item2->result1,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['term1_result'] !="null" )
                                        @if(json_decode($item2->result1,true)[$lesson_id]['term1_result']
                                        >=$lesson->min_mark)
                                        <span>
                                            {{ arabic_w2e(json_decode($item2->result1,true)[$lesson_id]['term1_result'] )}}</span>
                                        @else
                                        <span style="color: red;
                                        text-decoration: underline;">
                                            {{ arabic_w2e(json_decode($item2->result1,true)[$lesson_id]['term1_result'] )}}</span>
                                        @endif
                                        @break

                                        @endif

                                        @endforeach
                                        @endif
                                    </td>

                                    <td>
                                        @if($item2->estimation1)
                                        @foreach( json_decode($item2->estimation1,true) as $key=>$item)
                                        @if($key == $lesson_id )
                                        {{$item}}
                                        @break

                                        @endif

                                        @endforeach

                                        @endif
                                    </td>
                                    <td>
                                        @if($item2->key==0)
                                         @can('edit_student_marks')
                                        <button type="submit" class="btn"
                                            style=" background: linear-gradient(to right top, #2c71ad 20%, #84a7c4);color :white;">ارسال
                                        </button>
                                         @endcan
                                        @endif

                                    </td>
                                    @endforeach
                                </tr>
                            </form>
                            @endforeach
                            @endif
                          





                        </tbody>
                    </table>




                </section>
                <!-- end mark subject -->
                <section>
                    <h2>الفصل الثاني </h2>
                    <table style="text-align: center;">
                        <thead style="text-align: center;">
                            <tr style="text-align: center;">
                                <th rowspan="2" colspan="1" style="text-align: center;">الطلاب </th>
                                <th rowspan="2" colspan="1" style="text-align: center;"> الدرجة العظمى </th>
                                <th rowspan="1" colspan="4" style="text-align: center;"> درجة اعمال الفصل الثاني </th>
                                <th rowspan="1" colspan="1" style="text-align: center;">درجة اختبار الفصل الثاني </th>
                                <th rowspan="1" colspan="1" style="text-align: center;">مجموع درجات الفصل الثاني </th>
                                <th rowspan="2" colspan="1" style="text-align: center;">تقدير الفصل الثاني </th>
                                <th rowspan="2" colspan="1" style="text-align: center;">مجموع درجات الفصلين</th>
                                <th rowspan="2" colspan="1" style="text-align: center;"> متوسط درجات الفصلين </th>
                                <th rowspan="2" colspan="1" style="text-align: center;"> التقدير النهائي </th>
                                <th rowspan="2" colspan="1" style="text-align: center;"> ارسال </th>
                            </tr>
                            <tr>
                                <th rowspan="1" colspan="1" style="text-align: center;">شفوية <br> <span
                                        style="color: #f38639;">%١٠</span> </th>
                                <th rowspan="1" colspan="1" style="text-align: center;"> وظائف و اوراق عمل <br> <span
                                        style="color: #f38639;">%١٠</span> </th>
                                <th rowspan="1" colspan="1" style="text-align: center;"> نشاطات و مبادرات <br> <span
                                        style="color: #f38639;">%٢٠</span></th>
                                <th rowspan="1" colspan="1" style="text-align: center;"> المذاكرات <br> <span
                                        style="color: #f38639;">%٢٠</span></th>
                                <th rowspan="1" colspan="1" style="text-align: center;"><span
                                        style="color: #f38639;">%٤٠</span>
                                </th>
                                <th rowspan="1" colspan="1" style="text-align:center;"><span
                                        style="color: #f38639;">%١٠٠</span>
                                </th>

                            </tr>
                        </thead>
                        <tbody style="text-align: center;">
                            @if ($students)
                            @foreach ( $students->student as $item )
                            <form action="{{ route('student_mark') }}" method="post">
                                @csrf
                                <tr>
                                    <input type="hidden" name="term" value="term2">
                                    <input type="hidden" name="room_id" value="{{ $room_id }}">
                                    <input type="hidden" name="student_id" value="{{$item->id}}">
                                    <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
                                    <td> {{ $item->first_name }} {{ $item->last_name }} </td>
                                    <td class="total" data-number="{{$lesson->max_mark	}}">{{arabic_w2e($lesson->max_mark)	}}  </td>
                                    @foreach ($item->student_mark as $item2)
                                    <td>
                                        @php
                                        $decodedData = json_decode($item2->mark2);
                                      @endphp
                                        @if (!$decodedData ||  (!property_exists($decodedData,  $lesson_id )) )
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="" name="oral" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.1}}"
                                            max="{{$lesson->max_mark*0.1}}">

                                        @endif
                                        @foreach( json_decode($item2->mark2,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['oral'] !="null" )
                                        @if(json_decode($item2->mark2,true)[$lesson_id]['oral'] == null)
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="{{ json_decode($item2->mark2,true)[$lesson_id]['oral']}}" name="oral"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.1}}" max="{{$lesson->max_mark*0.1}}">
                                        @else
                                        <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                            value="{{ json_decode($item2->mark2,true)[$lesson_id]['oral']}}" name="oral"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.1}}" max="{{$lesson->max_mark*0.1}}">
                                        @endif
                                        @break

                                        @endif

                                        @endforeach



                                    </td>


                                    <td>
                                        @php
                                        $decodedData = json_decode($item2->mark2);
                                      @endphp
                                        @if (!$decodedData ||  (!property_exists($decodedData,  $lesson_id )) )
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="" name="homework" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.1}}"
                                            max="{{$lesson->max_mark*0.1}}">

                                        @endif
                                        @foreach( json_decode($item2->mark2,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['homework'] !="null" )
                                        @if(json_decode($item2->mark2,true)[$lesson_id]['homework'] == null)
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="{{ json_decode($item2->mark2,true)[$lesson_id]['homework']}}"
                                            name="homework" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.1}}"
                                            max="{{$lesson->max_mark*0.1}}">
                                        @else
                                        <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                            value="{{ json_decode($item2->mark2,true)[$lesson_id]['homework']}}"
                                            name="homework" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.1}}"
                                            max="{{$lesson->max_mark*0.1}}">
                                        @endif
                                        @break

                                        @endif

                                        @endforeach



                                    <td>
                                        @php
                                        $decodedData = json_decode($item2->mark2);
                                      @endphp
                                        @if (!$decodedData ||  (!property_exists($decodedData,  $lesson_id )) )
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="" name="activities" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.2}}"
                                            max="{{$lesson->max_mark*0.2}}">

                                        @endif
                                        @foreach( json_decode($item2->mark2,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['activities'] !="null" )
                                        @if(json_decode($item2->mark2,true)[$lesson_id]['activities'] == null)
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="{{ json_decode($item2->mark2,true)[$lesson_id]['activities']}}"
                                            name="activities" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.2}}"
                                            max="{{$lesson->max_mark*0.2}}">
                                        @else
                                        <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                            value="{{ json_decode($item2->mark2,true)[$lesson_id]['activities']}}"
                                            name="activities" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.2}}"
                                            max="{{$lesson->max_mark*0.2}}">
                                        @endif
                                        @break

                                        @endif

                                        @endforeach


                                    </td>

                                    <td>
                                        @php
                                        $decodedData = json_decode($item2->mark2);
                                      @endphp
                                        @if (!$decodedData ||  (!property_exists($decodedData,  $lesson_id )) )
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="" name="quize" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.2}}"
                                            max="{{$lesson->max_mark*0.2}}">

                                        @endif
                                        @foreach( json_decode($item2->mark2,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['quize'] !="null" )
                                        @if(json_decode($item2->mark2,true)[$lesson_id]['quize'] == null)
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="{{ json_decode($item2->mark2,true)[$lesson_id]['quize']}}"
                                            name="quize" onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.2}}" max="{{$lesson->max_mark*0.2}}">
                                        @else
                                        <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                            value="{{ json_decode($item2->mark2,true)[$lesson_id]['quize']}}"
                                            name="quize" onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.2}}" max="{{$lesson->max_mark*0.2}}">
                                        @endif
                                        @break

                                        @endif

                                        @endforeach


                                    </td>

                                    <td>
                                        @php
                                        $decodedData = json_decode($item2->mark2);
                                      @endphp
                                        @if (!$decodedData ||  (!property_exists($decodedData,  $lesson_id )) )
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="" name="exam" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ''" class="common-input mb-20 form-control"
                                            type="number" min="0" data-max="{{$lesson->max_mark*0.4}}"
                                            max="{{$lesson->max_mark*0.4}}">

                                        @endif
                                        @foreach( json_decode($item2->mark2,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['exam'] !="null" )
                                        @if(json_decode($item2->mark2,true)[$lesson_id]['exam'] == null)
                                        <input class="number" style="height: 50px; width:60px; border: 1px solid red;"
                                            value="{{ json_decode($item2->mark2,true)[$lesson_id]['exam']}}" name="exam"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.4}}" max="{{$lesson->max_mark*0.4}}">
                                        @else
                                        <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                            value="{{ json_decode($item2->mark2,true)[$lesson_id]['exam']}}" name="exam"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.4}}" max="{{$lesson->max_mark*0.4}}">
                                        @endif
                                        @break

                                        @endif

                                        @endforeach


                                    </td>
                                    <td>
                                        @if($item2->result2)
                                        @foreach( json_decode($item2->result2,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['term2_result'] !="null" )
                                        @if(json_decode($item2->result2,true)[$lesson_id]['term2_result']
                                        >=$lesson->min_mark)
                                        <span>
                                            {{ arabic_w2e(json_decode($item2->result2,true)[$lesson_id]['term2_result'] )}}</span>
                                        @else
                                        <span style="color: red;
                                       text-decoration: underline;">
                                            {{ arabic_w2e(json_decode($item2->result2,true)[$lesson_id]['term2_result'] )}}</span>
                                        @endif
                                        @break

                                        @endif

                                        @endforeach
                                        @endif
                                    </td>
                                    <td>
                                        @if($item2->estimation2)
                                        @foreach( json_decode($item2->estimation2,true) as $key=>$item)
                                        @if($key == $lesson_id )
                                        {{$item}}
                                        @break

                                        @endif

                                        @endforeach

                                        @endif
                                    </td>
                                    <td class="c1"  > @if($item2->result)
                                      @foreach( json_decode($item2->result,true) as $key=>$item)
                                      @if($key == $lesson_id && $item['year_result'] !="null" )
                                    {{ arabic_w2e(json_decode($item2->result,true)[$lesson_id]['year_result']) }}
                                      @break

                                      @endif

                                      @endforeach
                                      @endif </td>



                                    <td>
                                        @if($item2->result)
                                        @foreach( json_decode($item2->result,true) as $key=>$item)
                                        @if($key == $lesson_id && $item['year_result'] !="null" )
                                        @if(ceil(json_decode($item2->result,true)[$lesson_id]['year_result']
                                        /2)>=$lesson->min_mark)
                                        {{     arabic_w2e(ceil(json_decode($item2->result,true)[$lesson_id]['year_result'] /2)) }}
                                        @else
                                        <span style="color: red;
                              text-decoration: underline;">
                                            {{     arabic_w2e(ceil(json_decode($item2->result,true)[$lesson_id]['year_result'] /2)) }}
                                        </span>
                                        @endif
                                        @break

                                        @endif

                                        @endforeach
                                        @endif
                                    </td>
                                    <td>
                                        @if($item2->estimation)
                                        @foreach( json_decode($item2->estimation,true) as $key=>$item)
                                        @if($key == $lesson_id )
                                        {{$item}}
                                        @break

                                        @endif

                                        @endforeach

                                        @endif
                                    </td>
                                    <td>
                                        @if($item2->key==0)
                                         @can('edit_student_marks')
                                        <button type="submit" class="btn"
                                            style=" background: linear-gradient(to right top, #2c71ad 20%, #84a7c4);color :white;">ارسال
                                        </button>
                                         @endcan
                                        @endif

                                    </td>
                                    @endforeach
                                </tr>

                            </form>
                            @endforeach
                            @endif





                        </tbody>
                    </table>



                </section>
                <!-- end mark subject -->



                <!-- start  mark subject -->

                <!-- start mark subject-->


            </div>
        </div>

        <div class="modal fade deleteEmployeeModal11">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form id="" method="POST" action="{{route('student_mark_admin')}}">
                        @csrf
                        <div class="modal-header">
                            <h4 class="modal-title"> اضافة علامة </h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">
                            <p>حدد العلامة </p>
                            <input type="hidden" name="room_id" value="{{ $room->id }}">
                            <input type="text" hidden name="lesson_id" value="{{$lesson->id}}">

                            <select name="term" class="form-control">
                                <option value="term1">
                                    فصل اول
                                </option>
                                <option value="term2">
                                    فصل ثاني
                                </option>
                            </select>
                            <br>
                            <input type="number"  class="common-input mb-20 form-control "  name="mark" max="{{$lesson->max_mark}}" min="0">
                        </div>
                        <div class="modal-footer">
                            <input type="button" class="btn btn-default" data-dismiss="modal" value="الغاء">

                            <button class="btn" type="submit">تم</button>


                        </div>
                    </form>
                </div>
            </div>
        </div>
          
          <div class="modal fade  add_mark">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form id="" method="POST" action="{{route('student_mark_admin_details')}}">
                        @csrf
                        <div class="modal-header">
                            <h4 class="modal-title"> اضافة تفصيلات  </h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">
                            <p>حدد العلامة </p>
                            <input type="hidden" name="room_id" value="{{ $room->id }}">
                            <input type="text" hidden name="lesson_id" value="{{$lesson->id}}">

                            <select name="term"  class="form-control">
                                <option value="term1">
                                    فصل اول
                                </option>
                                <option value="term2">
                                    فصل ثاني
                                </option>
                            </select>
                            <br>
                             <table style="text-align: center;">
                        <thead style="text-align: center;">
                         
                            <tr>
                                <th rowspan="1" colspan="1" style="text-align: center;">شفوية <br> <span
                                        style="color: #f38639;">%١٠</span> </th>
                                <th rowspan="1" colspan="1" style="text-align: center;"> وظائف و اوراق عمل <br> <span
                                        style="color: #f38639;">%١٠</span> </th>
                                <th rowspan="1" colspan="1" style="text-align: center;"> نشاطات و مبادرات <br> <span
                                        style="color: #f38639;">%٢٠</span></th>
                                <th rowspan="1" colspan="1" style="text-align: center;"> المذاكرات <br> <span
                                        style="color: #f38639;">%٢٠</span></th>
                                <th rowspan="1" colspan="1" style="text-align: center;"> امتحانات <br><span
                                        style="color: #f38639;">%٤٠</span>
                                </th>
                             
                                </th>

                            </tr>
                        </thead>
                        <tbody style="text-align: center;">
                            <tr>
                                <td>
                                       <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                             name="oral"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.1}}" max="{{$lesson->max_mark*0.1}}">
                                </td>
                                  <td>
                                       <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                             name="homework"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.1}}" max="{{$lesson->max_mark*0.1}}">
                                </td>
                                  <td>
                                       <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                             name="activities"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.2}}" max="{{$lesson->max_mark*0.2}}">
                                </td>
                                  <td>
                                       <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                             name="quize"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.2}}" max="{{$lesson->max_mark*0.2}}">
                                </td>
                                  <td>
                                       <input class="number"
                                            style="height: 50px; width:60px;border: 1px solid #e9d8db;"
                                             name="exam"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = ''"
                                            class="common-input mb-20 form-control" type="number" min="0"
                                            data-max="{{$lesson->max_mark*0.4}}" max="{{$lesson->max_mark*0.4}}">
                                </td>
                            </tr>
                        </tbody>
                        </table>   
                        </div>
                        <div class="modal-footer">
                        

                            <button class="btn" type="submit">تم</button>


                        </div>
                    </form>
                </div>
            </div>
        </div> 
          
          
          
          
          
        <div class="modal fade deleteEmployeeModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form id="form_delete" method="POST">
                        @csrf
                        @method('delete')
                        <div class="modal-header">
                            <h4 class="modal-title">Delete element</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">
                            <p>Are you sure you want to delete these Records?</p>
                            <p class="text-warning"><small>This action cannot be undone.</small></p>
                        </div>
                        <div class="modal-footer">
                            <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">

                            <button class="btn btn-danger">Delete</button>


                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
    $(document).on('keyup', '.number', function () {

        if ($(this).val() > $(this).data('max') || $(this).val() == "") {
            alert('لايمكن وضع القيمة');
            $(this).val("");
        }


    })
</script>
<script>
    $(document).on('click', '.one', function (e) {

        e.preventDefault();
        $.ajax({

            type: 'post',
            url: "{{ route('student_mark') }}",
            enctype: 'multipart/form-data',
            data: $(this).parent().parent().find('form:first').serialize(),
            success: function (data) {
                console.log(data);
                swal({
                    title: "حسنا",
                    text: "! تمت العملية بنجاح",
                    icon: "success",
                    button: "OK",
                    timer: 2000

                });
            },
            error: function (xhr) {

            }

        });




    });
    $(document).ready(function () {
        $('#mydiv2').hide();
        $('#mydiv3').hide();

        $('.delete').on('click', function () {
            var id = $(this).data('id');
            var url = "{{URL::to('SMARMANger/admin/students')}}";
            $('#form_delete').attr("action", url);


        });

        $('.mydiv2').on('click', function () {
            $('#mydiv2').show();

            $('#mydiv').hide();
            $('#mydiv3').hide();


        });

        $('.mydiv').on('click', function () {
            $('#mydiv').show();

            $('#mydiv2').hide();
            $('#mydiv3').hide();


        });

        $('.mydiv3').on('click', function () {
            $('#mydiv3').show();

            $('#mydiv').hide();

            $('#mydiv2').hide();


        });


        $('.test_type').on('change', function () {




            $('#mydiv').empty();
            if ($(this).val() == 1) {

                var type = "";
                type += `
  @if ($count!=0)

      <form action="{{ route('student_mark' ) }}" method="post">
      @csrf
  <table class="table align-items-center table-flush" style="direction:rtl;text-align:right;">
                  <thead class="thead-light">
                    <tr>
                      <th scope="col" class="sort" data-sort="budget"> الاسم</th>
                      <th scope="col" class="sort" data-sort="budget">الهاتف</th>
                      <th scope="col" class="sort" data-sort="budget">شفوية</th>




                    </tr>
                  </thead>
                  <tbody class="list">


                    @if ($students)

                      @foreach ($students->student as $item)

                     <tr>




                      <td class="budget">


                      {{$item->first_name}}  {{$item->last_name}}


                      </td>


                          <td class="budget">

                          {{$item->phone}}

                          </td>


      <form action="{{ route('student_mark')}}" method="post">
      @csrf
          @foreach( $item->student_mark as $key1=>$value1)
          @foreach (json_decode($value1['mark'],true) as $key2=>$value2)
          @if ($key2==$lesson_id)
          <td><input type="text" style="width: 40px" value=" {{ $value2['oral'] }}" name="oral[]" id=""></td>

          @endif

          @endforeach
          @endforeach
      <input type="hidden" name="student_id[]" value="{{ $item->id }}">
      <input type="hidden" name="room_id" value="{{ $room->id }}">
      <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
      <input type="hidden" name="term" value="term1">





                      </tr>
                     @endforeach
    @endif




                  </tbody>
                </table>
                <button class="btn btn-success">Click</button>
              </form>
              @endif


  `;

            } else if ($(this).val() == 2) {
                type = "";

                type += `
      @if ($count!=0)

      <form action="{{ route('student_mark') }}" method="post">
      @csrf

  <table class="table align-items-center table-flush" style="direction:rtl;text-align:right;">
                  <thead class="thead-light">
                    <tr>
                      <th scope="col" class="sort" data-sort="budget"> الاسم</th>
                      <th scope="col" class="sort" data-sort="budget">الهاتف</th>
                      <th scope="col" class="sort" data-sort="budget">وظائف و أوراق عمل</th>



                      {{-- <th scope="col" class="sort" data-sort="completion">Action</th> --}}

                    </tr>
                  </thead>
                  <tbody class="list">

                    @if ($students)


                      @foreach ($students->student as $item)

                     <tr>

                      <td class="budget">


                      {{$item->first_name}}  {{$item->last_name}}


                      </td>


                          <td class="budget">

                          {{$item->phone}}

                          </td>

                      {{-- <td class="text-right">
                          <div class="dropdown">
                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <i class="fas fa-ellipsis-v"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <a href=".deleteEmployeeModal" class="delete dropdown-item" data-toggle="modal"
                              data-id="{{$item->id}}"><i class="material-iconsni ni ni-fat-remove" data-toggle="tooltip"
                                  title="Delete">&#xE872; Delete</i></a>
                              <a class="dropdown-item" href="#">Another action</a>
                              <a class="dropdown-item" href="#">Something else here</a>
                            </div>
                          </div>

                        </td> --}}

                        @foreach( $item->student_mark as $key1=>$value1)
          @foreach (json_decode($value1['mark'],true) as $key2=>$value2)
          @if ($key2==$lesson_id)
          <td><input type="text" style="width: 40px" value=" {{ $value2['homework'] }}" name="homework[]" id=""></td>

          @endif

          @endforeach
          @endforeach
      <input type="hidden" name="student_id[]" value="{{ $item->id }}">
      <input type="hidden" name="room_id" value="{{ $room->id }}">
      <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
      <input type="hidden" name="term" value="term1">





                      </tr>
                     @endforeach

       @endif



                  </tbody>
                </table>
                <button class="btn btn-success">Click</button>

              </form>
              @endif

  `;

            } else if ($(this).val() == 3) {
                type = "";

                type += `
      @if ($count!=0)

      <form action="{{ route('student_mark') }}" method="post">
      @csrf

  <table class="table align-items-center table-flush" style="direction:rtl;text-align:right;">
                  <thead class="thead-light">
                    <tr>
                      <th scope="col" class="sort" data-sort="budget"> الاسم</th>
                      <th scope="col" class="sort" data-sort="budget">الهاتف</th>
                      <th scope="col" class="sort" data-sort="budget">نشاطات و مبادرات</th>



                      {{-- <th scope="col" class="sort" data-sort="completion">Action</th> --}}

                    </tr>
                  </thead>
                  <tbody class="list">


                    @if ($students)

                      @foreach ($students->student as $item)

                     <tr>

                      <td class="budget">


                      {{$item->first_name}}  {{$item->last_name}}


                      </td>


                          <td class="budget">

                          {{$item->phone}}

                          </td>

                      {{-- <td class="text-right">
                          <div class="dropdown">
                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <i class="fas fa-ellipsis-v"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <a href=".deleteEmployeeModal" class="delete dropdown-item" data-toggle="modal"
                              data-id="{{$item->id}}"><i class="material-iconsni ni ni-fat-remove" data-toggle="tooltip"
                                  title="Delete">&#xE872; Delete</i></a>
                              <a class="dropdown-item" href="#">Another action</a>
                              <a class="dropdown-item" href="#">Something else here</a>
                            </div>
                          </div>

                        </td> --}}


                        @foreach( $item->student_mark as $key1=>$value1)
          @foreach (json_decode($value1['mark'],true) as $key2=>$value2)
          @if ($key2==$lesson_id)
          <td><input type="text" style="width: 40px" value=" {{ $value2['activities'] }}" name="activities[]" id=""></td>

          @endif

          @endforeach
          @endforeach
      <input type="hidden" name="student_id[]" value="{{ $item->id }}">
      <input type="hidden" name="room_id" value="{{ $room->id }}">
      <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
      <input type="hidden" name="term" value="term1">





                      </tr>
                     @endforeach

   @endif



                  </tbody>
                </table>
                <button class="btn btn-success">Click</button>
              </form>

              @endif
  `;
            } else if ($(this).val() == 4) {
                type = "";

                type += `
      @if ($count!=0)

      <form action="{{ route('student_mark' ) }}" method="post">
      @csrf

  <table class="table align-items-center table-flush" style="direction:rtl;text-align:right;">
                  <thead class="thead-light">
                    <tr>
                      <th scope="col" class="sort" data-sort="budget"> الاسم</th>
                      <th scope="col" class="sort" data-sort="budget">الهاتف</th>
                      <th scope="col" class="sort" data-sort="budget">مذاكرة</th>



                      {{-- <th scope="col" class="sort" data-sort="completion">Action</th> --}}

                    </tr>
                  </thead>
                  <tbody class="list">


                    @if ($students)

                      @foreach ($students->student as $item)

                     <tr>

                      <td class="budget">


                      {{$item->first_name}}  {{$item->last_name}}


                      </td>


                          <td class="budget">

                          {{$item->phone}}

                          </td>

                      {{-- <td class="text-right">
                          <div class="dropdown">
                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <i class="fas fa-ellipsis-v"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <a href=".deleteEmployeeModal" class="delete dropdown-item" data-toggle="modal"
                              data-id="{{$item->id}}"><i class="material-iconsni ni ni-fat-remove" data-toggle="tooltip"
                                  title="Delete">&#xE872; Delete</i></a>
                              <a class="dropdown-item" href="#">Another action</a>
                              <a class="dropdown-item" href="#">Something else here</a>
                            </div>
                          </div>

                        </td> --}}



                        @foreach( $item->student_mark as $key1=>$value1)
          @foreach (json_decode($value1['mark'],true) as $key2=>$value2)
          @if ($key2==$lesson_id)
          <td><input type="text" style="width: 40px" value=" {{ $value2['quize'] }}" name="quize[]" id=""></td>

          @endif

          @endforeach
          @endforeach
      <input type="hidden" name="student_id[]" value="{{ $item->id }}">
      <input type="hidden" name="room_id" value="{{ $room->id }}">
      <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
      <input type="hidden" name="term" value="term1">





                      </tr>
                     @endforeach
@endif




                  </tbody>
                </table>

                <button class="btn btn-success">Click</button>
              </form>

              @endif

  `;
            } else if ($(this).val() == 5) {
                type = "";

                type += `
      @if ($count!=0)

      <form action="{{ route('student_mark') }}" method="post">
                          @csrf

  <table class="table align-items-center table-flush" style="direction:rtl;text-align:right;">
                  <thead class="thead-light">
                    <tr>
                      <th scope="col" class="sort" data-sort="budget"> الاسم</th>
                      <th scope="col" class="sort" data-sort="budget">الهاتف</th>
                      <th scope="col" class="sort" data-sort="budget">درجة اختبار الفصل الأول	</th>




                    </tr>
                  </thead>
                  <tbody class="list">




                    @if ($students)
                      @foreach ($students->student as $item)

                     <tr>


                      <td class="budget">


                      {{$item->first_name}}  {{$item->last_name}}


                      </td>


                          <td class="budget">

                          {{$item->phone}}

                          </td>




                          @foreach( $item->student_mark as $key1=>$value1)
          @foreach (json_decode($value1['mark'],true) as $key2=>$value2)
          @if ($key2==$lesson_id)
          <td><input type="text" style="width: 40px" value=" {{ $value2['exam'] }}" name="exam[]" id=""></td>

          @endif

          @endforeach
          @endforeach
      <input type="hidden" name="student_id[]" value="{{ $item->id }}">
      <input type="hidden" name="room_id" value="{{ $room->id }}">
      <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
      <input type="hidden" name="term" value="term1">





                      </tr>
                     @endforeach
@endif




                  </tbody>
                </table>
                <button class="btn btn-success">Click</button>

              </form>
              @endif

  `;

            }

            $('#mydiv').append(type);


        });












        // ==================================================================================================













        $('.test_type').on('change', function () {
            $('#mydiv2').empty();
            if ($(this).val() == 1) {
                var type = "";
                type += `
  @if ($count!=0)

  <form action="{{ route('student_mark') }}" method="post">
  @csrf
  <table class="table align-items-center table-flush" style="direction:rtl;text-align:right;">
  <thead class="thead-light">
  <tr>
  <th scope="col" class="sort" data-sort="budget"> الاسم</th>
  <th scope="col" class="sort" data-sort="budget">الهاتف</th>
  <th scope="col" class="sort" data-sort="budget">شفوية</th>



  {{-- <th scope="col" class="sort" data-sort="completion">Action</th> --}}

  </tr>
  </thead>
  <tbody class="list">


    @if ($students)

  @foreach ($students->student as $item)

  <tr>


  <td class="budget">


  {{$item->first_name}}  {{$item->last_name}}


  </td>


      <td class="budget">

      {{$item->phone}}

      </td>

  {{-- <td class="text-right">
      <div class="dropdown">
        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-ellipsis-v"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
        <a href=".deleteEmployeeModal" class="delete dropdown-item" data-toggle="modal"
          data-id="{{$item->id}}"><i class="material-iconsni ni ni-fat-remove" data-toggle="tooltip"
              title="Delete">&#xE872; Delete</i></a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </div>

    </td> --}}

  <form action="{{ route('student_mark') }}" method="post">
  @csrf
  @foreach( $item->student_mark as $key1=>$value1)
  @foreach (json_decode($value1['mark2'],true) as $key2=>$value2)
  @if ($key2==$lesson_id)
  <td><input type="text" style="width: 40px" value=" {{ $value2['oral'] }}" name="oral[]" id=""></td>

  @endif

  @endforeach
  @endforeach
  <input type="hidden" name="student_id[]" value="{{ $item->id }}">
  <input type="hidden" name="room_id" value="{{ $room->id }}">
  <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
  <input type="hidden" name="term" value="term2">





  </tr>
  @endforeach

  @endif



  </tbody>
  </table>
  <button class="btn btn-success">Click</button>
  </form>
  @endif

  `;

            } else if ($(this).val() == 2) {
                type = "";

                type += `
  @if ($count!=0)

  <form action="{{ route('student_mark' ) }}" method="post">
  @csrf

  <table class="table align-items-center table-flush" style="direction:rtl;text-align:right;">
  <thead class="thead-light">
  <tr>
  <th scope="col" class="sort" data-sort="budget"> الاسم</th>
  <th scope="col" class="sort" data-sort="budget">الهاتف</th>
  <th scope="col" class="sort" data-sort="budget">وظائف و أوراق عمل</th>



  {{-- <th scope="col" class="sort" data-sort="completion">Action</th> --}}

  </tr>
  </thead>
  <tbody class="list">



    @if ($students)
  @foreach ($students->student as $item)

  <tr>

  <td class="budget">


  {{$item->first_name}}  {{$item->last_name}}


  </td>


      <td class="budget">

      {{$item->phone}}

      </td>

  {{-- <td class="text-right">
      <div class="dropdown">
        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-ellipsis-v"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
        <a href=".deleteEmployeeModal" class="delete dropdown-item" data-toggle="modal"
          data-id="{{$item->id}}"><i class="material-iconsni ni ni-fat-remove" data-toggle="tooltip"
              title="Delete">&#xE872; Delete</i></a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </div>

    </td> --}}

    @foreach( $item->student_mark as $key1=>$value1)
  @foreach (json_decode($value1['mark2'],true) as $key2=>$value2)
  @if ($key2==$lesson_id)
  <td><input type="text" style="width: 40px" value=" {{ $value2['homework'] }}" name="homework[]" id=""></td>

  @endif

  @endforeach
  @endforeach
  <input type="hidden" name="student_id[]" value="{{ $item->id }}">
  <input type="hidden" name="room_id" value="{{ $room->id }}">
  <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
  <input type="hidden" name="term" value="term2">





  </tr>
  @endforeach

  @endif



  </tbody>
  </table>
  <button class="btn btn-success">Click</button>

  </form>

  @endif
  `;

            } else if ($(this).val() == 3) {
                type = "";

                type += `
  @if ($count!=0)

  <form action="{{ route('student_mark' ) }}" method="post">
  @csrf

  <table class="table align-items-center table-flush" style="direction:rtl;text-align:right;">
  <thead class="thead-light">
  <tr>
  <th scope="col" class="sort" data-sort="budget"> الاسم</th>
  <th scope="col" class="sort" data-sort="budget">الهاتف</th>
  <th scope="col" class="sort" data-sort="budget">نشاطات و مبادرات</th>



  {{-- <th scope="col" class="sort" data-sort="completion">Action</th> --}}

  </tr>
  </thead>
  <tbody class="list">


    @if ($students)

  @foreach ($students->student as $item)

  <tr>


  <td class="budget">


  {{$item->first_name}}  {{$item->last_name}}


  </td>


      <td class="budget">

      {{$item->phone}}

      </td>

  {{-- <td class="text-right">
      <div class="dropdown">
        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-ellipsis-v"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
        <a href=".deleteEmployeeModal" class="delete dropdown-item" data-toggle="modal"
          data-id="{{$item->id}}"><i class="material-iconsni ni ni-fat-remove" data-toggle="tooltip"
              title="Delete">&#xE872; Delete</i></a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </div>

    </td> --}}


    @foreach( $item->student_mark as $key1=>$value1)
  @foreach (json_decode($value1['mark2'],true) as $key2=>$value2)
  @if ($key2==$lesson_id)
  <td><input type="text" style="width: 40px" value=" {{ $value2['activities'] }}" name="activities[]" id=""></td>

  @endif

  @endforeach
  @endforeach
  <input type="hidden" name="student_id[]" value="{{ $item->id }}">
  <input type="hidden" name="room_id" value="{{ $room->id }}">
  <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
  <input type="hidden" name="term" value="term2">





  </tr>
  @endforeach
  @endif




  </tbody>
  </table>
  <button class="btn btn-success">Click</button>
  </form>
  @endif

  `;
            } else if ($(this).val() == 4) {
                type = "";

                type += `
  @if ($count!=0)

  <form action="{{ route('student_mark') }}" method="post">
  @csrf

  <table class="table align-items-center table-flush" style="direction:rtl;text-align:right;">
  <thead class="thead-light">
  <tr>
  <th scope="col" class="sort" data-sort="budget"> الاسم</th>
  <th scope="col" class="sort" data-sort="budget">الهاتف</th>
  <th scope="col" class="sort" data-sort="budget">مذاكرة</th>



  {{-- <th scope="col" class="sort" data-sort="completion">Action</th> --}}

  </tr>
  </thead>
  <tbody class="list" style="direction:rtl;text-align:right;">


    @if ($students)

  @foreach ($students->student as $item)

  <tr style="direction:rtl;text-align:right;">

  <td class="budget">


  {{$item->first_name}}  {{$item->last_name}}


  </td>


      <td class="budget">

      {{$item->phone}}

      </td>

  {{-- <td class="text-right">
      <div class="dropdown">
        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-ellipsis-v"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
        <a href=".deleteEmployeeModal" class="delete dropdown-item" data-toggle="modal"
          data-id="{{$item->id}}"><i class="material-iconsni ni ni-fat-remove" data-toggle="tooltip"
              title="Delete">&#xE872; Delete</i></a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </div>

    </td> --}}



    @foreach( $item->student_mark as $key1=>$value1)
  @foreach (json_decode($value1['mark2'],true) as $key2=>$value2)
  @if ($key2==$lesson_id)
  <td><input type="text" style="width: 40px" value=" {{ $value2['quize'] }}" name="quize[]" id=""></td>

  @endif

  @endforeach
  @endforeach
  <input type="hidden" name="student_id[]" value="{{ $item->id }}">
  <input type="hidden" name="room_id" value="{{ $room->id }}">
  <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
  <input type="hidden" name="term" value="term2">





  </tr>
  @endforeach


  @endif


  </tbody>
  </table>

  <button class="btn btn-success">Click</button>
  </form>
  @endif
  `;
            } else if ($(this).val() == 5) {
                type = "";

                type += `
  @if ($count!=0)

  <form action="{{ route('student_mark' ) }}" method="post">
      @csrf

  <table class="table align-items-center table-flush" style="direction:rtl;text-align:right;">
  <thead class="thead-light">
  <tr>
  <th scope="col" class="sort" data-sort="budget"> الاسم</th>
  <th scope="col" class="sort" data-sort="budget">الهاتف</th>
  <th scope="col" class="sort" data-sort="budget">درجة اختبار الفصل الأول	</th>




  </tr>
  </thead>
  <tbody class="list">



    @if ($students)

  @foreach ($students->student as $item)

  <tr>

  <td class="budget">


  {{$item->first_name}}  {{$item->last_name}}


  </td>


      <td class="budget">

      {{$item->phone}}

      </td>




      @foreach( $item->student_mark as $key1=>$value1)
  @foreach (json_decode($value1['mark2'],true) as $key2=>$value2)
  @if ($key2==$lesson_id)
  <td><input type="text" style="width: 40px" value=" {{ $value2['exam'] }}" name="exam[]" id=""></td>

  @endif

  @endforeach
  @endforeach
  <input type="hidden" name="student_id[]" value="{{ $item->id }}">
  <input type="hidden" name="room_id" value="{{ $room->id }}">
  <input type="hidden" name="lesson_id" value="{{ $lesson_id }}">
  <input type="hidden" name="term" value="term2">





  </tr>
  @endforeach


  @endif


  </tbody>
  </table>
  <button class="btn btn-success">Click</button>

  </form>
  @endif
  `;

            }

            $('#mydiv2').append(type);









        });


    });
</script>






@endsection

