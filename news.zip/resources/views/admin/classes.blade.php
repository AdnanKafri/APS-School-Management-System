@extends('admin.layouts.v2')

@section('page_title', 'الصفوف')
@section('page_subtitle', 'إدارة الصفوف والشعب الدراسية')
@section('style')
<style>
    .classes-index-v2 { direction: rtl; text-align: right; }
    /* ── Breadcrumbs ── */
    .v2-bc { display:flex; align-items:center; gap:.4rem; font-size:.9rem; flex-wrap:wrap; direction:rtl; }
    .v2-bc a { color:#8a869a; font-weight:700; text-decoration:none; }
    .v2-bc a:hover { color:#5B4B8A; }
    .v2-bc .sep { color:#b2aec0; font-weight:700; }
    .v2-bc .active { color:#2f2b3a; font-weight:700; }

    /* ── Card ── */
    .v2-section-card {
        border-radius: 18px;
        border: 1px solid rgba(91,75,138,0.12);
        box-shadow: 0 12px 32px rgba(36,30,62,0.08);
        background: #fff;
        overflow: hidden;
    }
    .v2-section-card .card-header {
        padding: 1.25rem 1.5rem !important;
        border-bottom: 1px solid rgba(91,75,138,0.1) !important;
        background: #fff !important;
    }
    .v2-section-card .card-header h3,
    .v2-section-card .card-header h2 {
        margin: 0 !important;
        font-weight: 800 !important;
        color: #2f2b3a !important;
        font-size: 1.1rem !important;
        text-align: right !important;
    }
    .classes-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        padding: 1rem 1.5rem 0;
        flex-wrap: wrap;
    }
    .classes-toolbar__meta {
        color: #7a748f;
        font-size: .92rem;
        font-weight: 700;
    }

    /* ── Table ── */
    .v2-table th {
        background: #f8f7fc !important;
        color: #2f2b3a !important;
        font-weight: 800 !important;
        font-size: .88rem !important;
        border-bottom: 2px solid rgba(91,75,138,0.1) !important;
        padding: .85rem !important;
        text-align: right !important;
        white-space: nowrap;
    }
    .v2-table td {
        vertical-align: middle !important;
        color: #3a3550 !important;
        font-size: .9rem !important;
        padding: .85rem !important;
        border-bottom: 1px solid rgba(91,75,138,0.06) !important;
        text-align: right !important;
    }
    .v2-table > tbody > tr:last-child > td { border-bottom: 0 !important; }
    .classes-actions {
        display: grid;
        grid-template-columns: repeat(2, minmax(96px, 1fr));
        gap: .55rem;
        min-width: 220px;
    }
    .classes-actions .btn {
        width: 100%;
        min-height: 42px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: .55rem .8rem;
        margin: 0 !important;
    }
    .class-thumb {
        width: 54px;
        height: 54px;
        object-fit: cover;
        border-radius: 14px;
        border: 1px solid rgba(91,75,138,0.12);
        box-shadow: 0 10px 20px rgba(36,30,62,0.08);
    }
    .classes-pagination {
        padding: 1rem 1.5rem 1.4rem;
        text-align: center;
    }
    .classes-pagination .hint-text {
        color: #7a748f;
        font-size: .9rem;
        margin-bottom: .65rem;
    }

    /* ── Action buttons ── */
    .v2-section-card .btn { border-radius: 12px !important; font-weight: 700 !important; font-size: .85rem !important; }

    /* ── Modals ── */
    .modal .modal-content { border-radius:16px; overflow:hidden; direction:rtl; text-align:right; box-shadow:0 20px 60px rgba(0,0,0,.18); }
    .modal .modal-header { padding:1rem 1.5rem; border-bottom:1px solid #e9ecef; align-items:center; }
    .modal .modal-header h4, .modal .modal-title { font-size:1rem; font-weight:700; color:#2f2b3a; margin:0; }
    .modal .modal-body { padding:1.5rem; }
    .modal .form-group { margin-bottom:1rem; }
    .modal .form-group label { font-weight:600; color:#3a3550; margin-bottom:.4rem; display:block; }
    .modal .form-control { border-radius:8px; border-color:#d0d5dd; padding:.45rem .75rem; font-size:.9rem; }
    .modal .form-control:focus { border-color:#7B67B2; box-shadow:0 0 0 3px rgba(91,75,138,.15); }
    .modal .modal-footer {
        padding:1rem 1.5rem;
        border-top:1px solid #e9ecef;
        gap:.6rem;
        display:flex;
        flex-wrap:wrap;
        align-items:center;
        justify-content:flex-start;
    }
    .modal .modal-footer .btn { min-height:40px; min-width:100px; font-weight:600; border-radius:10px; padding:.45rem 1.1rem; }
    .class-modal .modal-dialog {
        max-width: 760px;
        width: calc(100% - 2rem);
        margin: 1.75rem auto;
        display: flex;
        align-items: center;
        min-height: calc(100vh - 3.5rem);
    }
    .class-modal .modal-content {
        width: 100%;
        border-radius: 22px;
        border: 1px solid rgba(91,75,138,0.14);
        box-shadow: 0 28px 80px rgba(36,30,62,0.2);
    }
    .class-modal .modal-header {
        padding: 1.2rem 1.5rem;
        background: linear-gradient(180deg, rgba(91,75,138,0.05), rgba(91,75,138,0.01));
    }
    .class-modal .modal-title {
        font-size: 1.08rem;
        font-weight: 800;
    }
    .class-modal .modal-body {
        padding: 1.5rem;
        display: grid;
        gap: 1rem;
    }
    .class-modal .form-group {
        margin-bottom: 0;
    }
    .class-modal .form-group label {
        margin-bottom: .45rem;
        color: #2f2b3a;
        font-weight: 700;
    }
    .class-modal .form-control,
    .class-modal select.form-control {
        min-height: 46px;
        border-radius: 12px;
        padding: .7rem .9rem;
        border-color: rgba(123,103,178,0.22);
        background: #fcfbff;
    }
    .class-modal .form-control:focus,
    .class-modal select.form-control:focus {
        border-color: #7B67B2;
        box-shadow: 0 0 0 4px rgba(123,103,178,.12);
    }
    .class-modal .modal-footer {
        justify-content: flex-start !important;
        padding: 1rem 1.5rem 1.35rem;
    }
    .class-modal .modal-footer .btn,
    .class-modal .modal-footer a.btn {
        min-width: 120px;
        min-height: 44px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }
    .class-modal .close-btn {
        cursor: pointer;
    }
    .class-modal--compact .modal-dialog {
        max-width: 520px;
    }
    @media (max-width: 767px) {
        .class-modal .modal-dialog {
            width: calc(100% - 1rem);
            margin: .75rem auto;
            min-height: calc(100vh - 1.5rem);
        }
        .class-modal .modal-body {
            padding: 1rem;
        }
        .class-modal .modal-footer {
            justify-content: stretch !important;
        }
        .class-modal .modal-footer .btn,
        .class-modal .modal-footer a.btn {
            width: 100%;
        }
    }

    /* ── Misc ── */
    .pagination { justify-content:center !important; }
    button.close { margin:0 !important; padding:0 !important; }
    .custom-file-label { display:none !important; }
</style>
@endsection


@section('breadcrumbs')
<nav class="v2-bc" aria-label="Breadcrumb">
    <a href="{{ route('dashboard.index') }}">لوحة التحكم</a>
    <span class="sep">/</span>
    <span class="active">قسم الصفوف</span>
</nav>
@endsection

@section('content')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <div class="classes-index-v2">
    <div class="v2-section-card" style="margin: 1.25rem;">

        <!--@if (session()->has('success'))
    -->


        <!--<div class="alert alert-success alert-dismissible" role="alert" style="text-align: right; font-size: 30px">-->
        <!--    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
        <!--    {{ session()->get('success') }}-->
        <!--    </div>-->

        <!--
    @endif-->



        <div class="card-header border-0">
            <h3 class="mb-0">جدول الصفوف</h3>
        </div>

        <div class="classes-toolbar">
            <div class="classes-toolbar__meta">إدارة الصفوف الأساسية وربطها بالشعب الدراسية.</div>
            @can('create_class')
                <a href=".createClassModal" class="btn btn-success" data-toggle="modal" data-id="">إضافة صف</a>
            @endcan
        </div>

        <div class="table-responsive">
            <table class="table v2-table">
                <thead class="thead-light">
                    <tr>
                        <!--<th scope="col" class="sort" data-sort="name">Id</th>-->
                        <th scope="col" class="sort" data-sort="budget"> الاسم بالعربية</th>
                        <th scope="col" class="sort" data-sort="budget"> الاسم بالانكليزية</th>
                        <th scope="col" class="sort" data-sort="budget"> التكلفة </th>
                        <th scope="col" class="sort" data-sort="budget"> الصورة</th>
                        <th scope="col" class="sort" data-sort="budget"> العمليات</th>

                    </tr>
                </thead>
                <tbody class="list">
                    @foreach ($classes as $item)
                        <tr>

                            <td class="budget" style="font-weight:bold;font-size:15px">
                                {{ $item->name }}
                            </td>

                            <td class="budget"style="font-weight:bold;font-size:15px">
                                {{ $item->name_en }}
                            </td>
                            <td class="budget"style="font-weight:bold;font-size:15px">
                                {{ $item->fixed_cost }}
                            </td>
                            <td>


                                @if ($item->image != null)
                                    <img src="{{ asset('storage/' . $item->image) }}" class="class-thumb"
                                        alt="">
                                @endif
                            </td>

                            <td class="text-right">
                                <div class="classes-actions">
                                <a href="{{ route('classroom', $item->id) }}" class="btn btn-success">الشعب</a>
                                @can('update_class')
                                @if(count($item->stages)>0)
                                 <a href=".editClassModal" class="btn btn-secondary edit"
                                        data-name="{{ $item->name }}"
                                        data-name_en="{{ $item->name_en }}"
                                        data-fixed_cost="{{ $item->fixed_cost }}"
                                        data-description_en="{{ $item->description_en }}"
                                        data-description_ar="{{ $item->description_ar }}"
                                        data-cildren_count="{{ $item->cildren_count }}"
                                        data-lesson_count="{{ $item->lesson_count }}"
                                        data-week_count="{{ $item->week_count }}"
                                        data-cost_id="{{ $item->cost_id }}"
                                        data-image="{{ $item->image }}"
                                        data-stage_id="{{ $item->stage_id }}"
                                        data-stages_id="{{ $item->stages[0]->id }}"
                                        data-report_card="{{ $item->report_card }}"
                                         data-id="{{ $item->id }}"
                                           data-classcost="{{ $item->classCost }}"
                                            data-is_scientific="{{ $item->is_scientific }}"
                                        data-next_class="{{ $item->next_class }}" data-toggle="modal">
                                        تعديل </a>
                                        @else
                                         <a href=".editClassModal" class="btn btn-secondary edit"
                                        data-name="{{ $item->name }}"
                                        data-name_en="{{ $item->name_en }}"
                                        data-fixed_cost="{{ $item->fixed_cost }}"
                                        data-description_en="{{ $item->description_en }}"
                                        data-description_ar="{{ $item->description_ar }}"
                                        data-cildren_count="{{ $item->cildren_count }}"
                                        data-lesson_count="{{ $item->lesson_count }}"
                                        data-week_count="{{ $item->week_count }}"
                                        data-cost_id="{{ $item->cost_id }}"
                                        data-image="{{ $item->image }}"
                                        data-stage_id="{{ $item->stage_id }}"
                                        data-stages_id=""
                                        data-report_card="{{ $item->report_card }}"
                                         data-id="{{ $item->id }}"
                                            data-is_scientific="{{ $item->is_scientific }}"
                                           data-classcost="{{ $item->classCost }}"
                                        data-next_class="{{ $item->next_class }}" data-toggle="modal">
                                        تعديل </a>
                                @endif

                                @endcan
                                @can('delete_class')
                                    <a href=".deleteClassModal" class="delete2 btn btn-warning text-light "
                                        data-name="{{ $item->name }}" data-id="{{ $item->id }}" data-toggle="modal">
                                        حذف
                                    </a>
                                @endcan
                                </div>

                            </td>

                        </tr>
                    @endforeach


                </tbody>
            </table>

        </div>

        <div class="clearfix classes-pagination">
            <div class="hint-text">عرض الصفحة
                <b>{{ !request('page') ? '1' : request('page') }}</b>
                من أصل <b>{{ ceil($count / paginate_num) }}</b>
            </div>
            <div class="row">
                <div class="col-md-12">
                    {{ $classes->links() }}
                </div>
            </div>
        </div>


    </div>
    </div>



    {{-- $class_cost = Class_cost::whereIn('class_id', $all_classes->pluck('id'))
    ->whereIn('country_id', $countries_currencies->pluck('id'))
->get(); --}}



    <div class="modal fade createClassModal class-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="" action="{{ route('class_store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-header">
                        <h4 class="modal-title">اضافة صف</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group" style="text-align:right">
                            <label>اسم الصف بالعربية</label>
                            <input type="text" name="class_name" class="form-control" value=""
                                style="direction: rtl" placeholder="مثال :أول" maxlength="20" required>
                        </div>

                        <div class="form-group" style="text-align:right">
                            <label>اسم الصف بالانكليزية</label>
                            <input type="text" name="class_name_en" class="form-control" value=""
                                placeholder="example :first" maxlength="20" required>
                        </div>
                        <div class="form-group" style="text-align:right">
                                        <label>اذا كان الصف مرحلة ثانوية هل هو ادبي او علمي</label>
                                         <select name="is_scientific" id="" class="form-control"
                                            style="min-height: 36px;direction: rtl" >
                                            <option value="" hidden> حدد  هل      الصف ادبي او علمي     </option>

                                                <option value="1">أدبي</option>
                                                <option value="2"> علمي</option>

                                        </select>
                                    </div>
                        <div class="form-group" style="text-align:right">
                            <label>   الحلقة  الدراسية </label>

                            <select name="stage_id" id="" class="form-control lesson_id"
                                style="min-height: 36px;direction: rtl">
                                <option value="" hidden>حدد   الحلقة  الدراسية </option>
                                @foreach($stages as $stage)
                                <option value="{{$stage->id}}"> {{ $stage->name }}</option>
                                @endforeach

                            </select>
                        </div>
                        <div class="form-group" style="text-align:right">
                            <label> المرحلة الدراسية </label>

                            <select name="stages_id" id="" class="form-control lesson_id"
                                style="min-height: 36px;direction: rtl">
                                <option value="" hidden>حدد  المرحلة الدراسية </option>
                                @foreach($stage1 as $stage)
                                <option value="{{$stage->id}}"> {{ $stage->name }}</option>
                                @endforeach

                            </select>
                        </div>
                        {{-- <div class="form-group" style="text-align:right">
                            <label> المرحلة الدراسية </label>



                            <select name="stage_id" id="" class="form-control lesson_id"
                                style="min-height: 36px;direction: rtl">
                                <option value="" hidden>حدد المرحلة الدراسية </option>
                                <input id="cost_id" type="number" name="cost" class="form-control" value=""
                                style="direction: rtl">

                            </select>
                        </div> --}}
                        <div class="form-group" style="text-align:right">
                            <label> تصميم الجلاء </label>

                            <select name="report_card" id="" class="form-control lesson_id"
                                style="min-height: 36px;direction: rtl">
                                <option value="" hidden>حدد تصميم الجلاء </option>
                                <option value="0">عام / رياض الأطفال</option>
                                <option value="1"> صف 1-4</option>
                                <option value="2">صف 5-6</option>
                                <option value="3"> صف 7-8</option>
                                <option value="4"> صف 9</option>
                                <option value="5"> صف 10 علمي </option>
                                <option value="6"> صف 10 أدبي</option>
                                <option value="7"> صف 11 علمي </option>
                                <option value="8"> صف 11 أدبي</option>
                                <option value="9"> صف 12 علمي </option>
                                <option value="10"> صف 12 أدبي</option>
                                {{-- <option value="11">   فئة ب مستوى اول </option>
                                <option value="12">  فئة ب مستوى ثاني </option>
                                <option value="13"> فئة ب مستوى ثالث</option>
                                <option value="14"> فئة ب مستوى رابع   </option> --}}
                            </select>
                        </div>
                        <div class="form-group" style="text-align:right">
                            <label> تحديد الصف التالي عند النجاح </label>

                            <select name="next_class" id="" class="form-control "
                                style="min-height: 36px;direction: rtl">
                                <option value="" hidden>حدد الصف التالي </option>
                                @foreach ($all_classes as $class)
                                    <option value="{{ $class->id }}"> {{ $class->name }}</option>
                                @endforeach
                                <option value="0"> لا يوجد</option>
                            </select>
                        </div>
                        <div class="form-group" id="show" style="text-align:right">
                            <label> المبلغ </label>
                            <input type="number" id="fixed_cost" name="fixed_cost" class="form-control" value=""
                                placeholder="600" maxlength="20" required>
                        </div>
                        <div class="form-group" id="show" style="text-align:right">
                            <label> الوصف بالانكليزية </label>
                            <input type="text" id="description_en" name="description_en" class="form-control" value=""
                                placeholder="Example: An ideal class studying the approved curriculum." maxlength="255">
                        </div>
                        <div class="form-group" id="show" style="text-align:right">
                            <label> الوصف بالعربية </label>
                            <input type="text" id="description_ar" name="description_ar" class="form-control" value=""
                                placeholder="" maxlength="255">
                        </div>
                        <div class="form-group" id="show" style="text-align:right">
                            <label> عدد الطلاب</label>
                            <input type="number" id="cildren_count" name="cildren_count" min="0" class="form-control" value=""
                                placeholder="20" maxlength="20">
                        </div>
                        <div class="form-group" id="show" style="text-align:right">
                            <label> عدد الدروس  </label>
                            <input type="number" id="lesson_count" name="lesson_count" min="0" class="form-control" value=""
                                placeholder="24" maxlength="20">
                        </div>
                        <div class="form-group" id="show" style="text-align:right">
                            <label> عدد الأسابيع </label>
                            <input type="number" id="week_count" name="week_count" min="0" class="form-control" value=""
                                placeholder="16" maxlength="20">
                        </div>
                        {{-- <div class="form-group" id="show" style="text-align:right">
                            <input id="cost_id" type="hidden" name="cost" class="form-control" value=""
                            style="direction: rtl">
                            <!--<label>المبلغ</label>-->
                            <!--<select id="country_select" name="country_id[]" class="form-control">-->
                            <!--    <option value="">اختر البلد للدفع</option>-->
                            <!--    @foreach ($countries_currencies as $item)-->
                            <!--    @if ($item->active == 1)-->
                            <!--        <option value="{{ $item->id }}">{{ $item->name_ar }}</option>-->
                            <!--    @endif-->
                            <!--@endforeach-->
                            <!--</select>-->


                              @foreach ($countries_currencies as $item)
                                @if ($item->active == 1)
                                       <label> المبلغ {{ $item->name_ar }}   </label>
                                       <input  type="number"  class="form-control" name="countries[{{$item->id}}]"  required >
                                @endif
                            @endforeach
                            <br>
                            <br>

                        </div> --}}
                        <div class="form-group" style="text-align:right">
                            <label>الصورة</label>
                            <input type="file" name="image" onchange="loadFile(event)" id="input_image11"
                                class="input_image form-control" required>
                            <label class="custom-file-label" for="customFileLang">Select file</label>
                            <span class="close-btn del_img" title="الغاء" id="del_img"
                                style="display: none; font-weight:bold">&times;</span>
                            <img id="output" style=" display: none" src="" class="output" width="200px"
                                alt="">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-default" data-dismiss="modal">الغاء</a>
                        <button class="btn btn-primary">حفظ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
//     <script>

//     // Get the select element and the show_inputs div
//     var selectElement = document.getElementById('country_select');
//     var showInputsDiv = document.querySelector('.show_inputs');
//     var classIdInput = document.getElementById('class_id');
//     // Create an array to store the country IDs and costs
//     var countryData = [];
//     // Add event listener to the select element
//     selectElement.addEventListener('change', function() {
//         // Get the selected option's value and text
//         var selectedOption = selectElement.value;
//         var selectedOptionText = selectElement.options[selectElement.selectedIndex].text;
//         // Create a new input element
//         var newInput = document.createElement('input');
//         newInput.type = 'number';
//         newInput.name = 'cost';
//         newInput.className = 'form-control mb-3';
//         newInput.style.direction = 'rtl';
//         newInput.placeholder = 'ادخل المبلغ لدولة' + ' ' + selectedOptionText;
//         newInput.required = true;
//         // Append the new input element to the show_inputs div
//         showInputsDiv.appendChild(newInput);
//         // Store the country ID and cost in the countryData array
//         countryData.push({
//             country_id: selectedOption,
//             cost: null // You can set an initial value or leave it as null
//         });
//         // Remove the selected option from the select element
//         selectElement.remove(selectElement.selectedIndex);
//     });

//     // Function to send an AJAX request to store the cost value in the database
//     function storeCost(countryId, classId, cost) {
//         var xhr = new XMLHttpRequest();
//         xhr.open('POST', '/class_store', true);
//         xhr.setRequestHeader('Content-Type', 'application/json');
//         xhr.onreadystatechange = function() {
//             if (xhr.readyState === 4 && xhr.status === 200) {
//                 console.log(xhr.responseText);
//             }
//         };
//         xhr.send(JSON.stringify({
//             country_id: countryId,
//             class_id: classId,
//             cost: cost
//         }));
//     }

//     // Add event listener to the show_inputs div to capture cost value changes
//     showInputsDiv.addEventListener('change', function(event) {
//         var target = event.target;
//         if (target.tagName === 'INPUT' && target.name === 'cost') {
//             var index = Array.from(showInputsDiv.children).indexOf(target);
//             var value = parseFloat(target.value);
//             if (!isNaN(value)) {
//                 countryData[index].cost = value;
//                 // Call the storeCost function to store the cost value in the database
//                 storeCost(countryData[index].country_id, classIdInput.value, value);
//             } else {
//                 // Handle the case when the entered value is not a valid number
//                 alert('Please enter a valid number for the cost.');
//             }
//         }
//     });
// </script>








    <div class="modal fade editClassModal class-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="form_update" method="POST" action="{{ route('class_update') }}"
                    enctype="multipart/form-data">
                    @csrf

                    <div class="modal-header">
                        <h4 class="modal-title">تعديل الصف</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                         <input type="hidden" name="class_id" id="class_id10">
                        <div class="form-group" style="text-align:right">
                            <label>اسم الصف بالعربية</label>
                            <input type="text" name="class_name" class="form-control" required
                                        value="" style="direction: rtl" id="name"
                                        placeholder="مثال :أول" maxlength="20" >
                        </div>
                                          <div class="form-group" style="text-align:right">
                                        <label>اذا كان الصف مرحلة ثانوية هل هو ادبي او علمي</label>
                                         <select name="is_scientific" id="is_scientific" class="form-control is_scientific"
                                            style="min-height: 36px;direction: rtl" >
                                            <option value="" hidden> حدد  هل      الصف ادبي او علمي     </option>

                                                <option value="1">أدبي</option>
                                                <option value="2"> علمي</option>

                                        </select>
                                      </div>
                        <div class="form-group" style="text-align:right">
                            <label>اسم الصف بالانكليزية</label>
                             <input type="text" name="class_name_en" id="name_en" class="form-control"
                                        value=""
                                        placeholder="example :first" maxlength="20" >
                        </div>
                        <div class="form-group" style="text-align:right">
                            <label>   الحقلة الدراسية </label>

                            <select name="stage_id" id="stage_id" class="form-control stage_id"
                                style="min-height: 36px;direction: rtl">
                                <option value="" hidden>حدد  الحلقة الدراسية </option>
                                @foreach ($stages as $stage)
                                    <option value="{{ $stage->id }}"> {{ $stage->name }}</option>
                                @endforeach

                            </select>
                        </div>
                        <div class="form-group" style="text-align:right">
                            <label> المرحلة الدراسية </label>

                            <select name="stages_id" id="stages_id" class="form-control lesson_id"
                                style="min-height: 36px;direction: rtl">
                                <option value="" hidden>حدد  المرحلة الدراسية </option>
                                @foreach($stage1 as $stage)
                                <option value="{{$stage->id}}"> {{ $stage->name }}</option>
                                @endforeach

                            </select>
                        </div>
                        <div class="form-group" style="text-align:right">
                            <label> تصميم الجلاء </label>

                            <select name="report_card" id="report_card" class="form-control "
                                style="min-height: 36px;direction: rtl">
                                <option value="" hidden>حدد تصميم الجلاء </option>
                                <option value="0">عام / رياض الأطفال</option>
                                <option value="1"> صف 1-4</option>
                                <option value="2">صف 5-6</option>
                                <option value="3"> صف 7-8</option>
                                <option value="4"> صف 9</option>
                                <option value="5"> صف 10 علمي </option>
                                <option value="6"> صف 10 أدبي</option>
                                <option value="7"> صف 11 علمي </option>
                                <option value="8"> صف 11 أدبي</option>
                                <option value="9"> صف 12 علمي </option>
                                <option value="10"> صف 12 أدبي</option>
                                {{-- <option value="11">   فئة ب مستوى اول </option>
                                <option value="12">  فئة ب مستوى ثاني </option>
                                <option value="13"> فئة ب مستوى ثالث</option>
                                <option value="14"> فئة ب مستوى رابع   </option> --}}


                            </select>
                        </div>
                        <div class="form-group" style="text-align:right">
                            <label> تحديد الصف التالي عند النجاح </label>

                            <select name="next_class" id="next_class" class="form-control "
                                style="min-height: 36px;direction: rtl">
                                <option value="" hidden>حدد الصف التالي </option>
                                @foreach ($all_classes as $class)
                                    <option value="{{ $class->id }}"> {{ $class->name }}</option>
                                @endforeach
                                <option value="0"> لا يوجد</option>
                            </select>
                        </div>

                        <div class="form-group" style="text-align:right">
                            <label> المبلغ </label>
                             <input type="number" name="fixed_cost" id="fixed_cost" class="form-control"
                                        value=""
                                        placeholder="" maxlength="20" >
                        </div>
                        <div class="form-group" id="show" style="text-align:right">
                            <label> الوصف بالانكليزية </label>
                            <input type="text" id="description_en" name="description_en" class="form-control" value=""
                                placeholder="" maxlength="255">
                        </div>
                        <div class="form-group" id="show" style="text-align:right">
                            <label> الوصف بالعربية </label>
                            <input type="text" id="description_ar" name="description_ar" class="form-control" value=""
                                placeholder="" maxlength="255">
                        </div>
                        <div class="form-group" id="show" style="text-align:right">
                            <label> عدد الطلاب</label>
                            <input type="number" id="cildren_count" min="0" name="cildren_count" class="form-control" value=""
                                placeholder="" maxlength="20">
                        </div>
                        <div class="form-group" id="show" style="text-align:right">
                            <label> عدد الدروس  </label>
                            <input type="number" id="lesson_count" min="0" name="lesson_count" class="form-control" value=""
                                placeholder="" maxlength="20">
                        </div>
                        <div class="form-group" id="show" style="text-align:right">
                            <label> عدد الأسابيع </label>
                            <input type="number" id="week_count" min="0" name="week_count" class="form-control" value=""
                                placeholder="" maxlength="20">
                        </div>









                        <div class="form-group" style="text-align:right">
                            <label>الصورة </label>
                            <br>
                            <input type="hidden" class="del" name="del_img1" value="del_img1" disabled="disabled">

                            <img src="" width="50px" height="50px" class="del_edit_img" id="image"
                                alt="لايوجد">
                            <span class="close-btn del_icon" title="الغاء" id=""
                                style ="display:inline;font-size: 44px; color:red;font-weigh:bold;cursor:pointerld">&times;</span>

                            <input type="file" name="image" onchange="loadFile_edit(event)"
                                class="form-control input_image" id="input_edit_image1" lang="ar">
                            <label class="custom-file-label" for="customFileLang"> اختر صورة</label>


                            <span class="close-btn del_img" title="الغاء" id=""
                                style="display: none; font-weight:bold">&times;</span>
                            <img id="output" class="output" style=" display: none"src="" width="200px"
                                alt="">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-default" data-dismiss="modal">الغاء</a>
                        <button class="btn btn-primary">حفظ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



    <div class="modal fade deleteEmployeeModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="form_delete" method="POST">
                    @csrf
                    @method('delete')
                    <div class="modal-header">
                        <h4 class="modal-title">Delete element</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>Are you sure you want to delete these Records?</p>
                        <p class="text-warning"><small>This action cannot be undone.</small></p>
                    </div>
                    <div class="modal-footer">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">

                        <button class="btn btn-danger">Delete</button>


                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- delete class  --}}

    <div class="modal fade deleteClassModal class-modal class-modal--compact">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="form_delete" action="{{ route('class_delete') }}" method="POST" autocomplete="off">

                    @csrf
                    <input type="hidden" name="class_id_delete" id="class_id_delete" required>

                    <div class="modal-header">
                        <h4 class="modal-title" style="color: #f00">حذف الصف</h4>
                        <button type="button" class="close" style="color: #f00" data-dismiss="modal"
                            aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group" style="text-align:right">
                            <label style="font-size: 18px; font-weight:bold"> أدخل كود الحذف للتأكيد </label>


                            <input type="password" style="direction:rtl" id="delete_code" name="delete_code"
                                class="form-control a" value="" placeholder="أدخل كود الحذف  " required>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-dark" data-dismiss="modal">الغاء </a>
                        <button class="btn btn-danger">حفظ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    {{-- end delete class  --}}


    <script src="{{ asset('js/jquery-3.4.1.min.js') }}"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
    $('.edit').click(function() {
        var class_id = $(this).data('id');
        var name = $(this).data('name');
        var name_en = $(this).data('name_en');
        var fixed_cost = $(this).data('fixed_cost');
        var description_en = $(this).data('description_en');
        var description_ar = $(this).data('description_ar');
        var cildren_count = $(this).data('cildren_count');
        var lesson_count = $(this).data('lesson_count');
        var week_count = $(this).data('week_count');
        var cost_id = $(this).data('cost_id');
        var image = $(this).data('image');
        var stage_id = $(this).data('stage_id');
        var stages_id = $(this).data('stages_id');
        var report_card = $(this).data('report_card');
        var next_class = $(this).data('next_class');
         var classCost = $(this).data('classcost');
          var is_scientific = $(this).data('is_scientific');
          $.each($('.classCost10'), function (index, val) {
           $(this).val('');


          })
          $.each(classCost, function (index, val) {
           $(`.modal-body #${val.country_id}`).val(val.cost);


          })

        // Assign values to modal form fields
        $('.modal-body #class_id10').val(class_id);
        $('.modal-body #name').val(name);
        $('.modal-body #name_en').val(name_en);
        $('.modal-body #fixed_cost').val(fixed_cost);
        $('.modal-body #description_en').val(description_en);
        $('.modal-body #description_ar').val(description_ar);
        $('.modal-body #cildren_count').val(cildren_count);
        $('.modal-body #lesson_count').val(lesson_count);
        $('.modal-body #week_count').val(week_count);
        $('.modal-body #cost_id').val(cost_id);
        $('.modal-body #image').attr('src', image);
        $('.modal-body #stage_id').val(stage_id);
         $('.modal-body #stages_id').val(stages_id);
        $('.modal-body #report_card').val(report_card);
        $('.modal-body #next_class').val(next_class);
        $('.modal-body #is_scientific').val(is_scientific);

    });
});
    </script>
    <script>

        $('.alert-success').hide(5000);


        $(document).ready(function() {

            $('.delete').on('click', function() {

                var id = $(this).data('id');
                var url = "{{ URL::to('SMARMANger/admin/students') }}";
                $('#form_delete').attr("action", url);

            });



            // $('.edit').on('click', function () {
            //     var id = $(this).data('id');
            //     var name=$(this).data('name');
            //     var name_en=$(this).data('name_en');
            //     var image=$(this).data('image');
            //     var annual_installment=$(this).data('annual_installment');
            //     var stage_id=$(this).data('stage_id');
            //     var report_card=$(this).data('report_card');
            //     var next_class=$(this).data('next_class');
            //     $('#class_id').val(id);
            //     $('#name').val(name);
            //     $('#name_en').val(name_en);
            //     $('#image').attr('src',`{{ asset('storage/${image}') }}`);
            //     $('#annual_installment').val(annual_installment);
            //     $('#stage_id').val(stage_id);
            //     $('#report_card').val(report_card);
            //     $('#next_class').val(next_class);
            // });



            // // Clear previous content in the div
            // $('#annual_installment_div').empty();

            // // Generate unique IDs for each input field
            // var index = 0;
            // $.each(annual_installment, function (index, installment) {
            //     var installmentElement = $(`
        //         <input type="number" name="cost" id="annual_installment_${index}" class="form-control mb-2" value="${installment}" style="direction: rtl">
        //     `);
            //     $('#annual_installment_div').append(installmentElement);
            //     index++;
            // });



            $(document).on('click', '.delete2', function() {
                var id = $(this).data('id');
                var name = $(this).data('name');

                $('#name_delete').val(name);
                $('#class_id_delete').val(id);
            });


        });
    </script>

    <script>
        var loadFile = function(event) {
            var id = event.target.id;
            var input_image = document.getElementById(id);
            var output = input_image.nextElementSibling.nextElementSibling.nextElementSibling;
            var del_img = input_image.nextElementSibling.nextElementSibling;
            output.setAttribute('src', URL.createObjectURL(event.target.files[0]));
            output.onload = function() {

                output.setAttribute('style', 'display:inline');
                del_img.setAttribute('style',
                    'display:inline;font-size: 44px; color:red;font-weigh:bold;cursor:pointer');
            };

        };


        var loadFile_edit = function(event) {
            var id = event.target.id;
            var input_image = document.getElementById(id);
            var output = input_image.nextElementSibling.nextElementSibling.nextElementSibling;
            var del_img = input_image.nextElementSibling.nextElementSibling;
            input_image.previousElementSibling.setAttribute('style', 'display:none');
            input_image.previousElementSibling.previousElementSibling.setAttribute('style', 'display:none');

            output.setAttribute('src', URL.createObjectURL(event.target.files[0]));
            output.onload = function() {

                output.setAttribute('style', 'display:inline');
                del_img.setAttribute('style',
                    'display:inline;font-size: 44px; color:red;font-weigh:bold;cursor:pointer');
            };

        };


        $(document).on('click', '.del_img', function() {
            $(this).nextAll('.output').attr('style', 'display:none;');
            $(this).prevAll('.input_image:first').val('');
            $(this).hide();

        });

        $(document).on('click', '.del_icon', function() {
            $(this).prevAll('.del:first').attr('disabled', false);
            $(this).prevAll('.del_edit_img:first').hide();
            $(this).hide();

        });
    </script>
@endsection

