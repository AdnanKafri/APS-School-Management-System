<?php

namespace App\Http\Controllers\Admin;

use App\Classe;
use App\Http\Controllers\Controller;
use App\Room;
use App\Student;
use App\StudentLifecycleEvent;
use App\Services\StudentLifecycleService;
use App\Year;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class StudentLifecycleController extends Controller
{
    public function index(Request $request)
    {
        $search = trim((string) $request->get('search', ''));
        $students = Student::archived()
            ->with(['academicPlacements.room.classes', 'academicPlacements.year'])
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $like = '%' . addcslashes($search, '%_') . '%';
                    $q->where('first_name', 'like', $like)
                        ->orWhere('last_name', 'like', $like)
                        ->orWhere('first_name_en', 'like', $like)
                        ->orWhere('last_name_en', 'like', $like)
                        ->orWhere('public_record_number', 'like', $like);
                });
            })->orderBy('first_name')->paginate(25)->appends($request->query());

        return view('admin.student_lifecycle_archive', [
            'students' => $students,
            'years' => Year::orderByDesc('id')->get(),
            'activeYear' => Year::where('current_year', 1)->first(),
            'classes' => Classe::orderBy('id')->get(),
            'events' => StudentLifecycleEvent::whereIn('student_id', $students->pluck('id'))->latest('occurred_at')->get()->groupBy('student_id'),
        ]);
    }

    public function archive(Request $request, StudentLifecycleService $service)
    {
        $validator = Validator::make($request->all(), [
            'student_id' => 'required|integer',
            'reason' => 'required|string|max:1000',
        ], [
            'student_id.required' => __('student_lifecycle.validation.student_required'),
            'reason.required' => __('student_lifecycle.validation.reason_required'),
            'reason.max' => __('student_lifecycle.validation.reason_max'),
        ]);
        if ($validator->fails()) {
            return $this->studentListRedirect($request, 'error', __('student_lifecycle.errors.operation_failed'))
                ->withErrors($validator)
                ->withInput();
        }
        $data = $validator->validated();
        $student = Student::operational()->whereKey($data['student_id'])->firstOrFail();
        try {
            $service->archiveStudent($student, $data['reason'], optional(auth()->user())->id);
        } catch (\Throwable $e) {
            report($e);
            $message = __($e->getMessage()) === $e->getMessage()
                ? __('student_lifecycle.errors.operation_failed')
                : __($e->getMessage());
            return $this->studentListRedirect($request, 'error', $message);
        }
        return $this->studentListRedirect($request, 'success', __('student_lifecycle.messages.archived'));
    }

    /**
     * Return to the active Students list without accepting an arbitrary URL.
     * The list itself uses server-side DataTables, so its browser state must be
     * carried explicitly through the archive form.
     */
    private function studentListRedirect(Request $request, $flashKey, $message)
    {
        if ($request->input('return_context') !== 'students') {
            return back()->with($flashKey, $message);
        }

        $query = [];
        foreach (['list_class_id', 'list_room_id', 'list_stage_id', 'list_start', 'list_length'] as $key) {
            $value = $request->input($key);
            if ($value === null || $value === '' || filter_var($value, FILTER_VALIDATE_INT) === false) {
                continue;
            }
            $query[$key] = (int) $value;
        }

        $search = $request->input('list_search');
        if (is_string($search) && strlen($search) <= 200 && trim($search) !== '') {
            $query['list_search'] = $search;
        }

        return redirect()->route('students', $query)->with($flashKey, $message);
    }

    public function restore(Request $request, StudentLifecycleService $service)
    {
        $data = $request->validate([
            'student_id' => 'required|integer', 'year_id' => 'required|integer',
            'class_id' => 'required|integer', 'room_id' => 'required|integer',
            'reason' => 'required|string|max:1000',
        ], [
            '*.required' => __('student_lifecycle.validation.required'),
            'reason.max' => __('student_lifecycle.validation.reason_max'),
        ]);
        $student = Student::archived()->whereKey($data['student_id'])->firstOrFail();
        try {
            $service->restoreStudent($student, $data['year_id'], $data['class_id'], $data['room_id'], $data['reason'], optional(auth()->user())->id);
        } catch (\Throwable $e) {
            report($e);
            return back()->with('error', __($e->getMessage()) === $e->getMessage() ? __('student_lifecycle.errors.operation_failed') : __($e->getMessage()));
        }
        return back()->with('success', __('student_lifecycle.messages.restored'));
    }

    public function rooms(Request $request, $classId)
    {
        $yearId = (int) $request->get('year_id');
        return response()->json(Room::where('class_id', $classId)->where('year_id', $yearId)->orderBy('id')->get(['id', 'name']));
    }
}
