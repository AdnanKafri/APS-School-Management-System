<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentFollowUp extends Model
{
    public const LEVELS = ['weak', 'average', 'good', 'excellent'];

    protected $table = 'student_follow_ups';

    protected $fillable = [
        'student_id', 'teacher_id', 'lesson_id', 'year_id', 'term_id', 'class_id', 'room_id',
        'student_academic_placement_id', 'teacher_assignment_period_id', 'level', 'note',
        'observed_at', 'compliance_month', 'compliance_half', 'created_by_user_id', 'created_by_admin_user_id', 'created_via',
        'last_edited_by_user_id', 'edited_at', 'voided_at',
    ];

    protected $casts = [
        'observed_at' => 'datetime',
        'compliance_month' => 'date',
        'edited_at' => 'datetime',
        'voided_at' => 'datetime',
    ];

    public function teacher()
    {
        return $this->belongsTo(Teacher::class, 'teacher_id');
    }

    public function lesson()
    {
        return $this->belongsTo(Lesson::class, 'lesson_id');
    }

    public function year()
    {
        return $this->belongsTo(Year::class, 'year_id');
    }

    public function term()
    {
        return $this->belongsTo(Term_year::class, 'term_id');
    }

    public function room()
    {
        return $this->belongsTo(Room::class, 'room_id');
    }

    public function classRoom()
    {
        return $this->belongsTo(Classe::class, 'class_id');
    }

    public function isEditableBy($teacherId, $now)
    {
        return (int) $this->teacher_id === (int) $teacherId
            && !$this->voided_at
            && $now->lt($this->created_at->copy()->addHours(2));
    }
}
