<?php



use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;
// use App\Http\Middleware\getAvailableLecture;

use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//هاد السطر لتعريف متحول قيمة paginte
define('paginate_num', '10');


Route::get("xxx", function(){
    return View::make("website.index ");
 });

// ============================================================
// SECURITY FIX: Artisan utility routes — admin-only access
// Previously: open to all (no auth). Now: auth + type=2 only.
// URLs are unchanged to preserve any existing bookmarks.
// ============================================================
Route::middleware(['auth', 'roleadmin'])->group(function () {
    Route::get('/clear-cache', function () {
        Artisan::call('cache:clear');
        return 'Application cache has been cleared';
    });
    Route::get('/clear-config', function () {
        Artisan::call('config:clear');
        return 'Application config has been cleared';
    });
    Route::get('/make-job', function () {
        // NOTE: This route creates a test job — for dev use only.
        Artisan::call('make:job TestJob');
        return '-';
    });
    Route::get('publishpublish', function () {
        return Artisan::call('vendor:publish --provider="Maatwebsite\Excel\ExcelServiceProvider" --tag=config');
    });
});

//روات التوجيه الى صفحة انتهاء فترة استقبال طلبات التوظيف
Route::get('/Recruitment_competition', function () {
    $locale = LaravelLocalization::getCurrentLocale();
    if (!in_array($locale, ['ar', 'en'], true)) {
        $locale = app()->getLocale();
    }
    if (!in_array($locale, ['ar', 'en'], true)) {
        $locale = 'ar';
    }

    return redirect()->to(url($locale . '/Recruitment_competition'));
});

Route::get('adh-login', function () {
    return redirect()->to(url('ar/adh-login'));
});

Route::get('/robots.txt', 'PublicSeoController@robots')->name('seo.robots');
Route::get('/sitemap.xml', 'PublicSeoController@sitemap')->name('seo.sitemap');
Route::get('/site.webmanifest', 'PublicSeoController@manifest')->name('seo.manifest');
Route::get('/favicon.ico', 'PublicSeoController@favicon')->name('seo.favicon');
foreach (['ar', 'en'] as $staffFeedbackLocale) {
    Route::get('/' . $staffFeedbackLocale . '/staff-feedback', 'StaffFeedbackController@create')->name('website.staff_feedback.' . $staffFeedbackLocale);
    Route::post('/' . $staffFeedbackLocale . '/staff-feedback', 'StaffFeedbackController@store')->name('website.staff_feedback.store.' . $staffFeedbackLocale);
}
Route::get('/downloads/apps/{slug}', 'MobileApplicationDistributionController@download')->name('mobile-applications.download');

Route::post('/stu_register2', 'websitecontroller@stu_register')->name('website.stu_register');
Route::get('/gallery/media', 'websitecontroller@gallery_media')->name('gallery.media');
Route::get('redirectTo404', function () {
  return response()->view('errors.404', [], 404);
});

Route::group([
  'prefix' => LaravelLocalization::setLocale(),
  'middleware' => ['localeSessionRedirect', 'localizationRedirect', 'localeViewPath']
], function () {

  Auth::routes();

  Route::get('/', 'websitecontroller@index')->name('website.index');
  Route::get('/faq', 'websitecontroller@faq')->name('website.faq');
  Route::get('/parent-app', 'MobileApplicationDistributionController@parentApp')->name('website.parent_app');
  Route::get('/staff-apps', 'MobileApplicationDistributionController@staffApps')->name('website.staff_apps');
  Route::get('/contact_us', 'websitecontroller@contact_us')->name('website.contact_us');
  Route::get('/complaints', 'ComplaintController@create')->name('website.complaints');
  Route::post('/complaints', 'ComplaintController@store')->name('website.complaints.store');

  Route::get('/contact', function () {
    return redirect()->to(route('website.contact_us'), 301);
  })->name('website.contact');



  Route::post('/stu_register', 'websitecontroller@stu_register')->name('stu_register');
  Route::get('/registration-wizard', 'websitecontroller@registration_wizard')->name('website.registration_wizard');
  Route::get('/registration-wizard/payment-qr', 'websitecontroller@registration_payment_qr')->name('website.registration_payment_qr');

  // Multi-step registration foundation endpoints (Phase 1, no UI/payment integration).
  Route::prefix('registration-wizard')->group(function () {
    Route::post('/step-1-terms', 'RegistrationWizardController@saveStep1Terms')->name('registration_wizard.step1');
    Route::post('/step-2-form', 'RegistrationWizardController@saveStep2Form')->name('registration_wizard.step2');
    Route::post('/temp-file', 'RegistrationWizardController@storeTempFile')->name('registration_wizard.temp_file');
    Route::post('/step-3-transport', 'RegistrationWizardController@saveStep3Transport')->name('registration_wizard.step3');
    Route::post('/prepare-payment-summary', 'RegistrationWizardController@preparePaymentSummary')->name('registration_wizard.summary');
    Route::post('/final-submit', 'RegistrationWizardController@finalSubmit')->name('registration_wizard.final_submit');
  });

  Route::get('/lessons/{class_id}', 'websitecontroller@lessons')->name('website.lessons');

  Route::get('/about_us', function () {
    return redirect()->to(route('website.index') . '#about_us', 301);
  })->name('website.about_us');




  Route::get('/classes', function () {
    return redirect()->to(route('website.index') . '#classes', 301);
  })->name('website.classes');



  Route::get('/events', 'websitecontroller@events')->name('website.events');
  Route::get('/book/{id}', 'websitecontroller@book')->name('website.book');


  Route::get('/event/single/{event_id}', 'websitecontroller@event_single')->name('website.event.single');


  Route::get('/blogs', function () {
    return redirect()->to(route('website.index') . '#Blog', 301);
  })->name('website.blogs');


  Route::get('/blog/single/{blog_id}', 'websitecontroller@blog_single')->name('website.blog.single');


  Route::get('/news', function () {
    return redirect()->to(route('website.index') . '#Blog', 301);
  })->name('website.news');

  Route::get('/employment', 'websitecontroller@employment')->name('website.employment');

  Route::get('/Recruitment_competition', function () {
    return view('website.Recruitment-competition');
  })->name('Recruitment_competition');

  Route::get('/adh-login', 'websitecontroller@login')->name('website.login');


  Route::get('/news/single/{news_id}', 'websitecontroller@news_single')->name('website.news.single');



  Route::get('/jobs', 'websitecontroller@jobs')->name('website.jobs');

  Route::post('/applicant/store', 'websitecontroller@applicant_store')->name('website.applicant.store');

  Route::post('/employee/store', 'websitecontroller@store_employee')->name('website.store_employee');

  Route::get('/register', 'websitecontroller@registration_wizard')->name('website.register');
  Route::get('/register-legacy', 'websitecontroller@register')->name('website.register_legacy');

  Route::get('/faqs', function () {
    return redirect()->to(route('website.faq'), 301);
  })->name('website.faqs');


  Route::get('/search', 'websitecontroller@search')->name('website.search');
  Route::get('/ourteam', 'websitecontroller@ourteam')->name('website.ourteam');
});












Route::get('/SMARMANger', function () {
  if (Auth::check()) {
    if ((string) auth()->user()->type === \App\Services\ComplaintAccess::OFFICER_TYPE) {
      return redirect()->route('complaint-portal.index');
    }

    if (auth()->user()->type == '2') {
      return redirect()->route('dashboard.index');
    } else if (auth()->user()->type == '1') {
      return redirect()->route('dashboard.teacher');
    } elseif (auth()->user()->type == '0') {
      return redirect()->route('dashboard');
    } elseif (auth()->user()->type == '3') {
      return redirect()->route('dashboard.supervisor');
    }
  }
  return redirect()->route('website.index');
});


Route::post('login1', 'websitecontroller@login1')->name('login1');
Route::post('logout', 'Auth\LoginController@logout')->name('logout');






require base_path('routes/student.php');


require base_path('routes/supervisor.php');


require base_path('routes/coordinator.php');
require base_path('routes/acadsupervisor.php');


require base_path('routes/administrator.php');



require base_path('routes/teacher_legacy.php');
require base_path('routes/teacher.php');
require base_path('routes/admin.php');
require base_path('routes/complaint_portal.php');









require base_path('routes/smar_admin.php');


Route::get('/home', 'HomeController@index')->name('home');
Route::post('contact_website_store', 'websitecontroller@contact_store')->name('contact_store');

require base_path('routes/gradebook.php');
