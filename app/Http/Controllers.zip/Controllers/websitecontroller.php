<?php

namespace App\Http\Controllers;

use App\About_us;
use App\Applicant;
use App\Classe;
use App\Contact;
use App\Count;
use App\Event;
use App\Footer;
use App\Blog;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;
use App\Inside_slider;
use App\Header_info;

use App\Job;
use App\Lesson;
use App\News;
use App\Slider;
use App\Student;
use App\Video;
use Carbon\Carbon;
use Illuminate\Http\Request;

class websitecontroller extends Controller
{

    public function index(){


        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();
        $video=Video::first();
        $sliders=Slider::
        select('id','header_'.LaravelLocalization::setLocale().
        ' as header','image','content_'.LaravelLocalization::setLocale().' as content')->get();


        $news=News::
        select('id','title_'.LaravelLocalization::setLocale().
        ' as title','image1','content_'.LaravelLocalization::setLocale().' as content'
        ,'part1_'.LaravelLocalization::setLocale().
        ' as part1'
        ,'part2_'.LaravelLocalization::setLocale().
        ' as part2'
        ,'part3_'.LaravelLocalization::setLocale().
        ' as part3'
        ,'part4_'.LaravelLocalization::setLocale().
        ' as part4'
        ,'image2','image3','image4','created_at'
        )->
        orderBy('created_at', 'desc')
        ->limit(4)->get();

        $classes=Classe::all();
        $about_us=About_us::select('id','header_'.LaravelLocalization::setLocale().
        ' as header','content_'.LaravelLocalization::setLocale().' as content'
        ,'vission_'.LaravelLocalization::setLocale().
        ' as vission'
        ,'mission_'.LaravelLocalization::setLocale().
        ' as mission'
        ,'objective_'.LaravelLocalization::setLocale().
        ' as objective'
        ,'image','image_slider_top','image_slider_bottom','created_at'
        )->first();
        $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().' as address'
        ,'facebook','twitter','google','instgram','phone','email','created_at'
        )->first();        $super_students=Student::where('super','1')->get();

         $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();
        return view('website.index',compact('sliders','news','classes','about_us','video','count','header','footer','super_students'));


    }


    public function lessons($class_id){

$lessons=Lesson::where('class_id',$class_id)->get();

$count=$lessons->count();
$count2=Count::first();

$lessons1=[];
$lessons2=[];

for ($i=0; $i <6 ; $i++) {
if (isset($lessons[$i])) {
    $lessons1[$i]=$lessons[$i];
}
}

for ($i=6; $i <$count ; $i++) {

    if (isset($lessons[$i])) {
        $lessons2[$i]=$lessons[$i];
    }
}


$class=Classe::find($class_id);

$footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
' as content','address_'.LaravelLocalization::setLocale().' as address'
,'facebook','twitter','google','instgram','phone','email','created_at'
)->first();

$header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();

return view('website.lessons',compact('lessons1','lessons2','lessons','class','header','footer','count','count2'));


    }

    public function about_us(){
        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();

        $about_us=About_us::select('id','header_'.LaravelLocalization::setLocale().
        ' as header','content_'.LaravelLocalization::setLocale().' as content'
        ,'vission_'.LaravelLocalization::setLocale().
        ' as vission'
        ,'mission_'.LaravelLocalization::setLocale().
        ' as mission'
        ,'objective_'.LaravelLocalization::setLocale().
        ' as objective'
        ,'image','image_slider_top','image_slider_bottom','created_at'
        )->first();
        
        $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().' as address'
        ,'facebook','twitter','google','instgram','phone','email','created_at'
        )->first();

         $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();
        $inside_slider=Inside_slider::first();

        return view('website.about_us',['about_us'=>$about_us,'count'=>$count,'inside_slider'=>$inside_slider,'header'=>$header,'footer'=>$footer]);
    }


    public function contact(){


        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();
        $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().' as address'
        ,'facebook','twitter','google','instgram','phone','email','created_at'
        )->first();
                 $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();

        return view('website.contact',compact('count','header','footer'));
    }


    public function contact_store(Request $request){

        $contact= new Contact;
        $contact->name = $request->name;
        $contact->email = $request->email;
        $contact->subject = $request->subject;
        $contact->phone = $request->phone;
        if ($request->has('message_en')) {
            $contact->message_en = $request->message_en;
        }

        if ($request->has('message_ar')) {
            $contact->message_ar = $request->message_ar;
        }
            $contact->save();
        return redirect()->back()->with('success','Sending Successfully!');
        
    }


    public function classes(){

        $classes=Classe::all();
        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();
        
    $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
    ' as content','address_'.LaravelLocalization::setLocale().' as address'
    ,'facebook','twitter','google','instgram','phone','email','created_at'
    )->first();
    
             $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();

        return view('website.classes',compact('classes','count','header','footer'));
    }

    public function events(){

        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();
        $events=Event::select('id','header_'.LaravelLocalization::setLocale().
        ' as header'
        ,'content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().
        ' as address',
        'start_time','end_time'
        ,'image','created_at'
        )->paginate(4);
        $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().' as address'
        ,'facebook','twitter','google','instgram','phone','email','created_at'
        )->first();
        $inside_slider=Inside_slider::first();
         $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();

        return view('website.events',compact('events','count','header','footer','inside_slider'));
    }

    public function event_single($event_id){
        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();
        $event=Event::select('id','header_'.LaravelLocalization::setLocale().
        ' as header'
        ,'content_'.LaravelLocalization::setLocale().
        ' as content','start_time','end_time',
        'address_'.LaravelLocalization::setLocale().
        ' as address'
        ,'image','created_at'
        )->find($event_id);
        $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().' as address'
        ,'facebook','twitter','google','instgram','phone','email','created_at'
        )->first();
                 $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();

        return view('website.event_single',compact('event','count','header','footer'));
    }


    public function blogs(){

        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();
        $blogs=Blog::select('id','title_'.LaravelLocalization::setLocale().
        ' as title','image1'
        ,'part1_'.LaravelLocalization::setLocale().
        ' as part1'
        ,'part2_'.LaravelLocalization::setLocale().
        ' as part2'
        ,'part3_'.LaravelLocalization::setLocale().
        ' as part3'
        ,'part4_'.LaravelLocalization::setLocale().
        ' as part4'
        ,'image2','image3','image4','image5','image6','image7','image8','image9','image10','created_at'
        )->paginate(4);
        $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().' as address'
        ,'facebook','twitter','google','instgram','phone','email','created_at'
        )->first();

        $inside_slider=Inside_slider::first();
         $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();

        return view('website.blogs',compact('blogs','count','header','footer','inside_slider'));
    }

    public function blog_single($blog_id){
        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();
        $blog=Blog::select('id','title_'.LaravelLocalization::setLocale().
        ' as title','image1'
        ,'part1_'.LaravelLocalization::setLocale().
        ' as part1'
        ,'part2_'.LaravelLocalization::setLocale().
        ' as part2'
        ,'part3_'.LaravelLocalization::setLocale().
        ' as part3'
        ,'part4_'.LaravelLocalization::setLocale().
        ' as part4'
        ,'image2','image3','image4','image5','image6','image7','image8','image9','image10','created_at'
        )->find($blog_id);
        $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().' as address'
        ,'facebook','twitter','google','instgram','phone','email','created_at'
        )->first();
                 $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();

        return view('website.blog_single',compact('blog','count','header','footer'));
    }



  public function news(){


        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();
        $news=News::  select('id','title_'.LaravelLocalization::setLocale().
        ' as title','image1','content_'.LaravelLocalization::setLocale().' as content'
        ,'part1_'.LaravelLocalization::setLocale().
        ' as part1'
        ,'part2_'.LaravelLocalization::setLocale().
        ' as part2'
        ,'part3_'.LaravelLocalization::setLocale().
        ' as part3'
        ,'part4_'.LaravelLocalization::setLocale().
        ' as part4'
        ,'image2','image3','image4','created_at'
        )->paginate(4);
        $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().' as address'
        ,'facebook','twitter','google','instgram','phone','email','created_at'
        )->first();

        $inside_slider=Inside_slider::first();
         $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();

        return view('website.news',compact('news','count','header','footer','inside_slider'));
    }

    public function news_single($news_id){
        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();
        $news=News::  select('id','title_'.LaravelLocalization::setLocale().
        ' as title','image1','content_'.LaravelLocalization::setLocale().' as content'
        ,'part1_'.LaravelLocalization::setLocale().
        ' as part1'
        ,'part2_'.LaravelLocalization::setLocale().
        ' as part2'
        ,'part3_'.LaravelLocalization::setLocale().
        ' as part3'
        ,'part4_'.LaravelLocalization::setLocale().
        ' as part4'
        ,'image2','image3','image4','created_at'
        )->find($news_id);
        $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().' as address'
        ,'facebook','twitter','google','instgram','phone','email','created_at'
        )->first();
         $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();

        return view('website.news_single',compact('news','count','header','footer'));
    }



    public function jobs(){


        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();
        $jobs=Job::select('id','title_'.LaravelLocalization::setLocale().
        ' as title'
        ,'description_'.LaravelLocalization::setLocale().
        ' as description'
       ,'created_at'
        )->paginate(4);

        $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().' as address'
        ,'facebook','twitter','google','instgram','phone','email','created_at'
        )->first();
                 $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().   ' as address')->first();
        $inside_slider=Inside_slider::first();

        return view('website.jobs',compact('jobs','count','inside_slider','header','footer'));
    }

    public function applicant_store(Request $request) {

        $request->validate([

            'first_name' => 'required | max:50',
            'last_name'  => 'required | max:50',
            'email'      => 'required | email | max:100',
            'phone'      =>  'required | max:20',
            'job_id'     =>  'required | numeric',
        ]);



        $applicant = new Applicant;

        $applicant->first_name = $request->first_name;
        $applicant->last_name  = $request->last_name;
        $applicant->email      = $request->email;
        $applicant->phone      = $request->phone;
        $applicant->job_id     = $request->job_id;
        $applicant->extension  = $request->cv_file->extension();
        if ($request -> hasFile('cv_file')) {

            $applicant->file = $request->cv_file->store('applicantsfiles','public');
        }

        $applicant->save();

        return redirect()->back()->with('Sending Successfully !');

    }


    public function faqs(){
        
        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();
         $faqs = Contact::whereNotNull ('answer_ar')->select('id','message_'.LaravelLocalization::setLocale().
         ' as message','answer_'.LaravelLocalization::setLocale().
         ' as answer')->get();
         $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
         ' as content','address_'.LaravelLocalization::setLocale().' as address'
         ,'facebook','twitter','google','instgram','phone','email','created_at'
         )->first();
         $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().
        ' as address')->first();

         return view('website.faqs',compact('faqs','count','header','footer'));
    }
    
    
    
        public function search(Request $request) {



        $news=News::where('title_ar',"like", "%" . $request->text . "%")->
        orwhere('title_en',"like", "%" . $request->text . "%")->
        orwhere('content_ar',"like", "%" . $request->text . "%")->
        orwhere('content_en',"like", "%" . $request->text . "%")->
        orwhere('part1_ar',"like", "%" . $request->text . "%")->
        orwhere('part1_en',"like", "%" . $request->text . "%")->
        orwhere('part2_ar',"like", "%" . $request->text . "%")->
        orwhere('part2_en',"like", "%" . $request->text . "%")->
        orwhere('part3_ar',"like", "%" . $request->text . "%")->
        orwhere('part3_en',"like", "%" . $request->text . "%")->
        orwhere('part4_ar',"like", "%" . $request->text . "%")->
        orwhere('part4_en',"like", "%" . $request->text . "%")
        ->select('id','title_'.LaravelLocalization::setLocale().
        ' as title','image1','content_'.LaravelLocalization::setLocale().' as content'
        ,'part1_'.LaravelLocalization::setLocale().
        ' as part1'
        ,'part2_'.LaravelLocalization::setLocale().
        ' as part2'
        ,'part3_'.LaravelLocalization::setLocale().
        ' as part3'
        ,'part4_'.LaravelLocalization::setLocale().
        ' as part4'
        ,'image2','image3','image4','created_at'
        )->get();

        $events=Event::where('header_ar',"like", "%" . $request->text . "%")->
        orwhere('header_en',"like", "%" . $request->text . "%")->
        orwhere('content_ar',"like", "%" . $request->text . "%")->
        orwhere('content_en',"like", "%" . $request->text . "%")->
        orwhere('address_ar',"like", "%" . $request->text . "%")->
        orwhere('address_en',"like", "%" . $request->text . "%")->
        select('id','header_'.LaravelLocalization::setLocale().
        ' as header'
        ,'content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().
        ' as address',
        'start_time','end_time'
        ,'image','created_at')
        ->get();


        $blogs=Blog::where('title_ar',"like", "%" . $request->text . "%")->
        orwhere('title_en',"like", "%" . $request->text . "%")->
        orwhere('part1_ar',"like", "%" . $request->text . "%")->
        orwhere('part1_en',"like", "%" . $request->text . "%")->
        orwhere('part2_ar',"like", "%" . $request->text . "%")->
        orwhere('part2_en',"like", "%" . $request->text . "%")->
        orwhere('part3_ar',"like", "%" . $request->text . "%")->
        orwhere('part3_en',"like", "%" . $request->text . "%")->
        orwhere('part4_ar',"like", "%" . $request->text . "%")->
        orwhere('part4_en',"like", "%" . $request->text . "%")->
        select('id','title_'.LaravelLocalization::setLocale().
        ' as title','image1'
        ,'part1_'.LaravelLocalization::setLocale().
        ' as part1'
        ,'part2_'.LaravelLocalization::setLocale().
        ' as part2'
        ,'part3_'.LaravelLocalization::setLocale().
        ' as part3'
        ,'part4_'.LaravelLocalization::setLocale().
        ' as part4'
        ,'image2','image3','image4','image5','image6','image7','image8','image9','image10','created_at'
        )
        ->get();

        $jobs=Job::where('title_ar',"like", "%" . $request->text . "%")->
        orwhere('title_en',"like", "%" . $request->text . "%")->
        orwhere('description_ar',"like", "%" . $request->text . "%")->
        orwhere('description_en',"like", "%" . $request->text . "%")
        ->select('id','title_'.LaravelLocalization::setLocale().
        ' as title'
        ,'description_'.LaravelLocalization::setLocale().
        ' as description'
       ,'created_at'
        )
        ->get();

        $faqs=Contact::where('subject',"like", "%" . $request->text . "%")->
        orwhere('message_ar',"like", "%" . $request->text . "%")->
        orwhere('message_en',"like", "%" . $request->text . "%")->
        orwhere('answer_ar',"like", "%" . $request->text . "%")->
        orwhere('answer_en',"like", "%" . $request->text . "%")->whereNotNull('answer_ar')->select('id','subject','message_'.LaravelLocalization::setLocale().
        ' as message','answer_'.LaravelLocalization::setLocale().
        ' as answer')->get();


        $result_count= count($news)+count($blogs)+count($events)+count($faqs)+count($jobs);

        $count=Count::first();
        $count->count=$count->count+1;
        $count->save();

         $header=Header_info::select('id','email','address_'.LaravelLocalization::setLocale().
        ' as address')->first();

        $footer=Footer:: select('id','content_'.LaravelLocalization::setLocale().
        ' as content','address_'.LaravelLocalization::setLocale().' as address'
        ,'facebook','twitter','google','instgram','phone','email','created_at'
        )->first();

        return view('website.search_result',compact('result_count','news','blogs','events','faqs','jobs','header','footer','count'));
    }
    
}
