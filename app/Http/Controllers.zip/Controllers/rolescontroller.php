<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Role;
use Artisan;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Shuttle_Dumper;
use Shuttle_Exception;

class rolescontroller extends Controller
{

    public function __construct()
{
    include app_path() . '/BackupDataBase.php';
}



public function databasebackup()
    {
        try {
            $world_dumper = Shuttle_Dumper::create(array(
                'host' => 'localhost',
                'username' => 'root',
                'password' => '',
                'db_name' => 'smartsyrianschoo_school2',
                //'include_tables' => array('country', 'city'), // only include those tables
                //'exclude_tables' => array('city'),
            ));

            // $world_dumper->dump('cep.sql.gz');
            $path = base_path('backup') . '/backup_' . Carbon::now()->format('Y-m-d')
            . '_' . Carbon::now()->format('H')
            . '_' . Carbon::now()->format('m')
            . '_' . Carbon::now()->format('i') .'_.sql';
            $world_dumper->dump($path);
            header('Content-Type: application/octet-stream');
            header("Content-Transfer-Encoding: Binary");
            header("Content-disposition: attachment; filename=\"" . basename($path) . "\"");
            readfile($path);
            Session::flash('success', 'تم أخذ نسخة احتياطية بنجاح');
            return redirect()->back();
        } catch (Shuttle_Exception $e) {
            echo "Couldn't dump database: " . $e->getMessage();
        }
    }







public function importedatabase(Request $request)
    {
        $this->validate($request, [
            'sql' => 'required',
        ]);

        $sql = $request->file('sql');
        $filename = $sql->getClientOriginalName();
        $path = base_path('backup/') . $filename;
        DB::unprepared(file_get_contents($path));
        Session::flash('success', 'تمت العملية بنجاح');
        return redirect('/backup_view');
    }




    public function index() {

        $roles=Role::all();

        return view('roles.index',compact('roles'));
    }

    public function store(Request $request) {
        $role=new Role;
        $role->name = $request->name;
        $role->permissions = json_encode($request->permissions);
        $role->save();
        return redirect()->back()->with('success','! تمت العملية بنجاح');


    }

    public function edit($id) {

        $role=Role::find($id);
$permissions= $role->permissions;
 $view=view('roles.ajax')->with('permissions',$permissions)->renderSections();
return response()->json([
'status'=>true,
'data'=>$view['content'],
]);

}

public function update(Request $request) {

    $role=Role::find($request->role_id);
    $role->name=$request->name;
    $role->permissions = json_encode($request->permissions);
    $role->save();
    return redirect()->back()->with('success','! تمت العملية بنجاح');

}

}
