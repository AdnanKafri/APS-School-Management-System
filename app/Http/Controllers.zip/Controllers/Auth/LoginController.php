<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    // protected $redirectTo = RouteServiceProvider::HOME;
    public function redirectTo()
{
    if (auth()->user()->type=='2') {
        return ('SMARMANger/admin/contacts');

    }elseif(auth()->user()->type=='1'){
        return ('SMARMANger/dashboard/teacher');

    }elseif(auth()->user()->type=='0'){
        return ('SMARMANger/dashboard/student');

    }
        elseif(auth()->user()->type=='3'){
        return ('SMARMANger/dashboard/supervisor');

    }
}
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
            Auth::logout();
        $this->middleware('guest')->except('logout');
    }


}
