<?php

namespace App\Http\Controllers;

use App\Classe;
use App\Lesson;
use App\Lesson_teacher_room_term_exam;
use App\Room;
use App\Message;
use App\Teacher_event;
use Carbon\Carbon;

use App\Student;
use App\Student_lesson_teacher_room_term_exam;
use App\Students_mark;
use App\Teacher;
use App\Teacher_room_lesson;
use App\Term_year;
use App\User;
use App\Year;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\Console\Input\Input;
use DateTime;
use RealRashid\SweetAlert\Facades\Alert;

class teacherscontroller extends Controller
{
      public function __construct()
    {
        $this->middleware(function($request,$next){
            if (session('success')) {
                Alert::success(session('success'));
            }

            if (session('warning')) {
                Alert::warning(session('warning'));
            }

            return $next($request);
        });
    }


    public function dashboard_teacher()
    {
        $teacher_id = Auth::user()->teacher_id;
        $teacher = Teacher::find($teacher_id);
        $year=Year::where('current_year','1')->first();
        

        return view('teachers.dashboard', compact('teacher'));
    }

    public function update_profile(Request $request, $teacher_id)
    {

        $teacher = Teacher::find($teacher_id);

        if ($request->image != null) {
            Storage::disk('public')->delete($teacher->image);
            $teacher->image = $request->image->store('filesteachers', 'public');
        }

        $teacher->save();
        return redirect()->back()->with('success', '! تمت العملية بنجاح ');
    }


    public function update_password(Request $request, $teacher_id)
    {

        // return $teacher_id;
        $user = User::find($teacher_id);
        // return $user;

        $this->validate($request, [
            'old_password'          => 'required',
            'password'              => 'required|min:4',
            'password_confirmation' => 'required|same:password'
        ]);
        if (Hash::check($request->old_password, $user->password)) {

            $user->password = Hash::make($request->password);
            $user->view_password = $request->password;

            $user->save();
        } else {
            return redirect()->back()->with('warning', '! كلمة المرور القديمة خاطئة');
        }


        return redirect()->back()->with('success', '! تمت العملية بنجاح ');
    }
    public function teacher_classes($teacher_id)
    {

        $year=Year::where('current_year','1')->first();

        $teacher = Teacher::with(['rooms'=>fn($q1)=>$q1->where('rooms.year_id',$year->id)])->find($teacher_id); 
        $classes = [];
        foreach ($teacher->rooms as $item) {

            $classes[] = $item->classes;
        }
        $classes = array_unique($classes);



        return view('teachers.classes', compact('classes', 'teacher'));
    }

    public function teacher_rooms($class_id, $teacher_id)
    {

        $year=Year::where('current_year','1')->first();

        $teacher = Teacher::with(['rooms'=>fn($q1)=>$q1->where('rooms.year_id',$year->id)])->find($teacher_id);
        $rooms = $teacher->rooms;

        $class_rooms = [];
        foreach ($rooms as $room) {

            if($room->class_id == $class_id) {
                $class_rooms[] = $room;


            }
        }

        $class_rooms = array_unique($class_rooms);

        return view('teachers.rooms', compact('class_rooms', 'teacher'));
    }



    public function teacher_lessons($room_id, $teacher_id)
    {

        $teacher = Teacher::find($teacher_id);
        $lessons = $teacher->lessons;
        $room_lessons = [];
        $teacher_room_lessons = Teacher_room_lesson::where('room_id', $room_id)->where('teacher_id', $teacher_id)->get();
        $teacher_lessons = [];
        foreach ($teacher_room_lessons as $teacher_room_lesson) {

            $teacher_lessons[] = Lesson::find($teacher_room_lesson->lesson_id);
        }
        return view('teachers.lessons', compact('teacher_lessons', 'teacher', 'room_id'));
    }


 

    public function StudentsRoomLesson($room_id, $teacher_id, $lesson_id)
    {
        $year=Year::where('current_year','1')->first();

$lesson=Lesson::find($lesson_id);
        $teacher = Teacher::find($teacher_id);

        $room = Room::find($room_id);

        $students = $room->student;

        $students=Room::with(['student.student_mark'=>fn($q1)=>$q1->where('students_marks.year_id',$year->id)])->find($room_id);

        if ($lesson->lang=='1') {
            $students=$students->student()->where('students.lang','1')->orderBy('first_name')->get();

        }elseif($lesson->lang=='0') {

            $students=$students->student()->where('students.lang','0')->orderBy('first_name')->get();

        }elseif($lesson->religion=='1') {
            $students=$students->student()->where('students.religion','1')->orderBy('first_name')->get();

        }elseif($lesson->religion=='0') {

            $students=$students->student()->where('students.religion','0')->orderBy('first_name')->get();

        }
        else{

            $students=$students->student()->orderBy('first_name')->get() ;

        }



        if(! $students->count() > 0 ) {

            return redirect()->back()->with('warning','! لا يوجد طلاب');
        }
 


        return view('teachers.students', compact('students', 'teacher', 'lesson_id', 'room_id'));
    }
 

    public function classes_lessons($teacher_id)
    {

        
        $year=Year::where('current_year','1')->first();

        $teacher = Teacher::with(['rooms'=>fn($q1)=>$q1->where('rooms.year_id',$year->id)])->find($teacher_id);

        $classes = [];


        // return $teacher ;
        foreach ($teacher->rooms as $item) {

            $classes[] = $item->classes;
        }
        $classes = array_unique($classes);

        $terms = Term_year::all();

        $lessons = Lesson::all();
        return view('teachers.classes_lessons', compact('classes', 'teacher', 'terms', 'lessons'));
    }

    public function teacher_rooms2($class_id, $teacher_id)
    {

        $year=Year::where('current_year','1')->first();

        $classes=Classe::with(['room'=>fn($q1)=>$q1->where('rooms.year_id',$year->id)])->find($class_id);
        $rooms=$classes->room;
$rooms1=[];
foreach($rooms as $room){

$a=Teacher_room_lesson::where('teacher_id',$teacher_id)->where('room_id',$room->id)->first();
if($a!=null){
    $rooms1[]=$a;

}

}

$rooms1=array_unique($rooms1);

$rooms2=[];
foreach($rooms1 as $room1){

$rooms2[]=Room::find($room1->room_id);

}


$rooms2=array_unique($rooms2);

// $rooms=Teacher_room_lesson::where('')

        // $class = Classe::find($class_id);
        // $teachers = Classe::with(['teachers' => fn ($q1) => $q1->with(['rooms' => fn ($q2) => $q2->where('rooms.class_id', $class_id)])])
        //     ->where('id', $class_id)->first();


        // $teachers = $teachers->teachers->where('id', $teacher_id);
        // $teachers2 = [];
        // foreach ($teachers as $teacher) {

        //     $teachers2[] = $teacher;
        // }
        // $teachers2 = array_unique($teachers2);
        // $rooms2= $teachers2[0]->rooms;

//         $rooms=[];
//         foreach ($rooms2 as $room) {
//             $rooms[]=$room;
//         }
// $rooms2=array_unique($rooms);

        // $rooms = Room::with(['teachers' => fn ($query) => $query->where('teacher_id', $teacher_id)
        //     ->with(['lessons' => fn ($q) => $q->where('class_id', $class_id)])])
        //     ->where('class_id', $class_id)->get();

        $lessons = [];
        foreach ($rooms as $item) {
            if (count($item->teachers) > 0) {

                foreach ($item->teachers[0]->lessons as $item2) {

                    $lessons[] = $item2;
                }
            }
        }
        $lessons = array_unique($lessons);



        $teacher = Teacher::find($teacher_id);
        $rooms = $teacher->rooms;

        $class_rooms = [];
        foreach ($rooms as $room) {

            $class_rooms[] = $room->where('class_id', $class_id)->get();
        }
        $class_rooms = array_unique($class_rooms);

        $terms = Term_year::all();
        // $lessons=Lesson::where('class_id',$class_id)->get();
        return view('teachers.rooms2', compact('rooms2', 'class_id', 'terms', 'teacher', 'lessons'));
    }

    public function store_items(Request $request)
    { 

        if ($request->video == null && $request->video_in == null && $request->test == null && $request->quize == null && $request->exam == null && $request->test_link == null && $request->quize_link == null && $request->exam_link == null && $request->addition == null) {

            return redirect()->back()->with('warning', 'المحتوى فارغ يرجى اعادة تعبئة البيانات من جديد');
        }


        if ($request->room_id == '0') {


            $teacher = Teacher::find($request->teacher_id);
            $rooms = $teacher->rooms->where('class_id', $request->class_id);
            $rooms1 = [];
            foreach ($rooms as $room) {
                $rooms1[] = $room;
            }
            $rooms1 = array_unique($rooms1);

            foreach ($rooms1 as $room) {

                $item = new Lesson_teacher_room_term_exam;
                $item->lesson_id = $request->lesson_id;
                $item->teacher_id = $request->teacher_id;
                $item->room_id = $room->id;
                $item->term_id = $request->term_id;
                $item->type = $request->type;

                   if ($request->video_in && $request->hasFile('video_in')) {
                $item->video = $request->video_in->store('filesteachers', 'public');
                                $item->type_video='0';

            }
            
            
                        if ($request->video!=null) {
                $item->video = $request->video;
                
                $item->type_video='1';
            }


                if ($request->test_link!=null) {


                    
$item->test = $request->test_link;
$item->start_time = $request->test_start_time;
$item->end_time = $request->test_end_time; 
$item->type_file =  '1';
                }
                elseif( $request->test && $request->hasFile('test')){

                    $item->test = $request->test->store('filesteachers', 'public');
                    $item->start_time = $request->test_start_time;
                    $item->end_time = $request->test_end_time;
            }

                if ($request->quize_link!=null ) {

                                    
$item->quize = $request->quize_link;
$item->start_time = $request->quize_start_time;
$item->end_time = $request->quize_end_time;
$item->type_file =  '1';
                }
                elseif($request->quize && $request->hasFile('quize')){
                    $item->quize = $request->quize->store('filesteachers', 'public');
                    $item->start_time = $request->quize_start_time;
                    $item->end_time = $request->quize_end_time;
                    

            }

                if ($request->exam_link!=null) {

                    
$item->exam =  $request->exam_link;
$item->start_time = $request->exam_start_time;
$item->end_time = $request->exam_end_time;
$item->type_file =  '1';

                }
                elseif($request->exam && $request->hasFile('exam') ){
                                    $item->exam =  $request->exam->store('filesteachers', 'public');
                    $item->start_time = $request->exam_start_time;
                    $item->end_time = $request->exam_end_time;

            }

                if ($request->addition && $request->hasFile('addition')) {
                    $item->addition =  $request->addition->store('filesteachers', 'public');
                    $item->extension =  $request->addition->extension();
                }
                $item->save();
            }
        } else {

            //     $curTime = new \DateTime();
            //    return date("Y-m-d H:i:s", strtotime('+3 hours'));

            $item = new Lesson_teacher_room_term_exam;
            $item->lesson_id = $request->lesson_id;
            $item->teacher_id = $request->teacher_id;
            $item->room_id = $request->room_id;
            $item->term_id = $request->term_id;
            $item->type = $request->type;

            
                        if ($request->video_in && $request->hasFile('video_in')) {
                $item->video = $request->video_in->store('filesteachers', 'public');
                                $item->type_video='0';

            }
            
            
                        if ($request->video!=null) {
                $item->video = $request->video;
                
                $item->type_video='1';
            }

            if ($request->test_link!=null) {
        $item->test = $request->test_link;
        $item->start_time = $request->test_start_time;
        $item->end_time = $request->test_end_time; 
        $item->type_file =  '1';

            }
            elseif( $request->test && $request->hasFile('test')){
                $item->test = $request->test->store('filesteachers', 'public');
                $item->start_time = $request->test_start_time;
                $item->end_time = $request->test_end_time;
            }

            if ($request->quize_link!=null) {
                
                
$item->quize = $request->quize_link;
$item->start_time = $request->quize_start_time;
$item->end_time = $request->quize_end_time;
$item->type_file =  '1';

            }
            elseif( $request->quize && $request->hasFile('quize')){

  
                $item->quize = $request->quize->store('filesteachers', 'public');
                $item->start_time = $request->quize_start_time;
                $item->end_time = $request->quize_end_time;
            }

            if ($request->exam_link!=null) {
 
            $item->type_file =  '1';
            
            $item->exam =  $request->exam_link;
            $item->start_time = $request->exam_start_time;
            $item->end_time = $request->exam_end_time;
            }
            elseif($request->exam && $request->hasFile('exam') ){
                 $item->exam =  $request->exam->store('filesteachers', 'public');
                $item->start_time = $request->exam_start_time;
                $item->end_time = $request->exam_end_time;
                
            }

            if ($request->addition && $request->hasFile('addition')) {
                $item->addition =  $request->addition->store('filesteachers', 'public');
                $item->extension =  $request->addition->extension();
            }


            $item->save();
        }

        return redirect()->back()->with('success', '! تمت العملية بنجاح ');
    }


    public function teacher_lessons2($room_id, $teacher_id)
    {

        $teacher = Teacher::find($teacher_id);
        $lessons = $teacher->lessons;
        $room_lessons = [];
        $teacher_room_lessons = Teacher_room_lesson::where('room_id', $room_id)->where('teacher_id', $teacher_id)->get();
        $teacher_lessons = [];
        foreach ($teacher_room_lessons as $teacher_room_lesson) {

            $teacher_lessons[] = Lesson::find($teacher_room_lesson->lesson_id);
        }
        
         $teacher_lessons=array_unique($teacher_lessons);
        return view('teachers.lessons2', compact('teacher_lessons', 'teacher', 'room_id'));
    }


    public function book_details($lesson_id, $teacher_id, $room_id)
    {
        $teacher = Teacher::find($teacher_id);
        $book_details = Lesson_teacher_room_term_exam::where('lesson_id', $lesson_id)->where('teacher_id', $teacher_id)
            ->where('room_id', $room_id)->orderBy("id",'desc')->get();
        $lesson = Lesson::find($lesson_id);
        $videos = $book_details->where('type', '0');
        $tests = $book_details->where('type', '1');
        $quizes = $book_details->where('type', '2');
        $exams = $book_details->where('type', '3');
        $additions = $book_details->where('type', '4');

        $date = new DateTime();
        $now = $date->format('Y-m-d H:i:s');

// $now=Carbon::now();

        // return $now;
$class=Room::find($room_id)->classes;
$room=Room::find($room_id);

        return view('teachers.book_details', compact(
            'teacher',
            'now',
            'room_id',
            'lesson',
            'book_details',
            'videos',
            'tests',
            'quizes',
            'exams',
            'additions',
            'class',
            'room'
            
        ));
    }


    public function file_answers($file_id, $lesson_id, $teacher_id, $room_id)
    {

        $answers = Student_lesson_teacher_room_term_exam::where('file_id', $file_id)->where('room_id', $room_id)->where('teacher_id', $teacher_id)->where('lesson_id', $lesson_id)->get();
        $room = Room::find($room_id);
        $students = $room->student;
$file=Lesson_teacher_room_term_exam::find($file_id);

        $teacher = Teacher::find($teacher_id);
        return view('teachers.answers', compact('answers','file', 'teacher', 'students'));
    }


    public function room_lessons(Request $request){

        if ($request->room_id !='0') {


            $items=Teacher_room_lesson::where('room_id',$request->room_id)
            ->where('teacher_id',$request->teacher_id)->get();
            $lessons=[];
            foreach($items as $item){

                $lessons[]=Lesson::where('id',$item->lesson_id)->first();
            }
            $lessons=array_unique($lessons);



        }
        else{

            $rooms=Room::where('class_id',$request->class_id)->get();
$items=[];
            foreach($rooms as $room){

                $items[]=Teacher_room_lesson::where('room_id',$room->id)
                ->where('teacher_id',$request->teacher_id)->get();

            }
            $lessons=[];

            foreach($items as $item1){

                foreach($item1 as $item){
                    $lessons[]=Lesson::where('id',$item->lesson_id)->first();


                }

            }

            $lessons=array_unique($lessons);
        }

        return  $lessons;

    }




    public function marks_status($room_id,$lesson_id) {


        $year=Year::where('current_year','1')->first();
        $teacher=Teacher::find(auth()->user()->teacher_id);


        $rooms_all=$teacher->rooms;

        // use collect function to unique array

          $collection=collect($rooms_all);
           $rooms=$collection->each(function($obj, $key) {
        })->unique('id');

        $students = [];
        foreach ($rooms as $room) {

        $students[]=$room->student;
        }
         $students=array_unique($students);


        $student= $students[0]->first();

 $mark_status= Teacher_room_lesson::where('room_id',$room_id)->where('lesson_id',$lesson_id)->where('year_id',$year->id)->where('teacher_id',$teacher->id)->first();

return view('teachers.marks_status',compact('teacher','student','mark_status','room_id','lesson_id'));



    }



    public function students($teacher_id){

        $teacher = Teacher::find($teacher_id);
        $year=Year::where('current_year','1')->first();

        $rooms=Teacher::with(['rooms.student'=>fn($q1)=>$q1->where('room_student.year_id',$year->id)])->find($teacher_id);

        $classes=[];
        foreach ($rooms->rooms as $item) {

            $classes[]=$item->classes;

        }
        $classes=collect($classes);
        $classes= $classes->unique();
        return view('teachers.teacher_students',compact('classes','teacher'));

    }

    public function class_rooms($class_id,$teacher_id) {
        $year=Year::where('current_year','1')->first();
        $rooms1= Teacher_room_lesson::where('teacher_id',$teacher_id)->where('class_id',$class_id)->where('year_id',$year->id)->get();
        $rooms1=$rooms1->unique('room_id');

        $rooms=[];

        foreach ($rooms1 as $room) {

            $rooms[]=Room::find($room->room_id);

        }

        return $rooms;

    }

    public function room_students($room_id) {

        $room=Room::find($room_id);
        $students=$room->student;

        return $students;

    }

    public function write_message($student_id){

        $student = Student::find($student_id);
        $teacher_id=auth()->user()->teacher_id;

        $teacher=Teacher::find($teacher_id);
        return view('teachers.write_message',compact('student','teacher'));

    }

    public function send_message($student_id, Request $request) {

        $year=Year::where('current_year' , '1')->first();
        $message = new Message;
        $message->year_id = $year->id;
        $message->student_id = $student_id;
        $message->message= $request->message;
        $message->save();
        return redirect()->back();

    }

    public function write_group_message($room_id){

         $teacher_id=auth()->user()->teacher_id;
        $room = Room::find($room_id);
        $teacher=Teacher::find($teacher_id);

        return view('teachers.write_group_message',compact('room','teacher'));

    }

    public function send_group_message($room_id, Request $request) {

        $year=Year::where('current_year' , '1')->first();
        $room=Room::find($room_id);
$students=$room->student;
foreach ($students as $item) {

    $message = new Message;
    $message->year_id = $year->id;
    $message->student_id = $item->id;
    $message->message= $request->message;
    $message->save();

}

        return redirect()->back();

    }



    public function events() {

        $events=Teacher_event::where('teacher_id',auth()->user()->teacher_id)->get();
        $teacher=Teacher::find(auth()->user()->teacher_id);
        return view('teachers.events',compact('events','teacher'));

    }

    public function add_event() {

        $teacher=Teacher::find(auth()->user()->teacher_id);
        $classes=$teacher->classes->unique();
        $teacher=Teacher::find(auth()->user()->teacher_id);

        return view('teachers.add_event',compact('classes','teacher'));
    }

    public function event_store(Request $request) {

        
        $year=Year::where('current_year','1')->first();

        $request->validate([
            'class_id' => 'required|numeric' ,
            'room_id'  =>  'required|numeric',
            'title'    =>   'required|max:30',
            'content'  =>   'required|max:100',
            'date'     =>    'required',
        ]);


        $teacher_event= new Teacher_event;

        $teacher_event->class_id = $request->class_id ;
        $teacher_event->room_id = $request->room_id ;
        $teacher_event->year_id = $year->id;
        $teacher_event->teacher_id = auth()->user()->teacher_id;
        $teacher_event->title = $request->title;
        $teacher_event->content = $request->content;
        $teacher_event->date = $request->date;

        $teacher_event->save();

        return redirect()->back()->with('success','! تمت العملية بنجاح ');

    }


    public function delete_event(Request $request){

        $answer=Teacher_event::find($request->id);

        
        $answer->delete();

        return response()->json([
            'status' => true ,
            'msg'=> 'تم الحذف بنجاح ' ,

        ]);
        // return redirect()->back()->with('success','تم حذف الملف بنجاح !');



    }
    
    
    
    public function addition_delete(Request $request){

    $file_id=$request->id;

    $file=Lesson_teacher_room_term_exam::find($file_id);
    $answers=Student_lesson_teacher_room_term_exam::where('file_id',$file->id)->delete();
    $file->delete();
    return redirect()->back()->with('success','! تمت العملية بنجاح ');

}
    

    public function file_edit($file_id){
        $year=Year::where('current_year','1')->first();


$lessons=Teacher::find(auth()->user()->teacher_id);
    $file=Lesson_teacher_room_term_exam::find($file_id);
    
    
    $classes=Teacher::find(auth()->user()->teacher_id)->classes->unique();

    $class_old=Room::find($file->room_id)->classes;
    // $rooms=Room::where('class_id',$class_old->id)->where('rooms.year_id',$year->id)->get();
    $rooms=$lessons->rooms()->where('teacher_room_lesson.class_id',$class_old->id)->where('teacher_room_lesson.year_id',$year->id)->get()->unique();
    $room_old=Room::find($file->room_id);
    // $lessons=Lesson::where('class_id',$class_old->id)->get();
    $lessons= $lessons->lessons()->where('teacher_room_lesson.class_id',$class_old->id)->where('teacher_room_lesson.year_id',$year->id)->get()->unique();
        $lesson_old=Lesson::find($file->lesson_id);
                        $teacher=Teacher::find(auth()->user()->teacher_id);

return view('teachers.file_edit',compact('file','classes','lessons','teacher','lesson_old','rooms','class_old','room_old'));

}




    public function file_update($file_id,Request $request){
    $item=Lesson_teacher_room_term_exam::find($file_id);
    if($request->room_id != $item->room_id)
    {
$answers=Student_lesson_teacher_room_term_exam::where('file_id',$item->id)->where('room_id',$item->room_id)->delete();
$item->room_id=$request->room_id;
}else{
    $item->room_id=$request->room_id;
    
    
        if($request->lesson_id != $item->lesson_id)
{
    
    $answers=Student_lesson_teacher_room_term_exam::where('file_id',$item->id)->where('room_id',$item->room_id)->update(['lesson_id'=>$request->lesson_id]);
    $item->lesson_id=$request->lesson_id;

}

}

if($item->test=='1'){
    
    if($request->test_link==null && $request->test_link==null && $request->test_link==null && $request->test==null && $request->quize==null && $request->exam==null) {
        
        return redirect()->back()->with('success','لم تقم بوضع رابط او ملف جديد');
        
    }
}

                if ($request->test && $request->hasFile('test') && $request->test_link==null) {

                    $item->test = $request->test->store('filesteachers', 'public');
                    $item->start_time = $request->test_start_time;
                    $item->end_time = $request->test_end_time;
                    $item->type = '1';
                    $item->type_file = '0';

                }

                if ($request->quize && $request->hasFile('quize') && $request->quize_link==null) {
                    $item->quize = $request->quize->store('filesteachers', 'public');
                    $item->start_time = $request->quize_start_time;
                    $item->end_time = $request->quize_end_time;
                    $item->type = '2';
                    $item->type_file = '0';

                }

                if ($request->exam && $request->hasFile('exam') && $request->exam_link==null) {
                    $item->exam =  $request->exam->store('filesteachers', 'public');
                    $item->start_time = $request->exam_start_time;
                    $item->end_time = $request->exam_end_time;
                     $item->type = '3';
                  $item->type_file = '0';


                }

// -----------------------

                if ($request->exam_link!=null) {
                    
                  $item->exam =  $request->exam_link;
                    $item->start_time = $request->exam_start_time;
                    $item->end_time = $request->exam_end_time;
                     $item->type = '3';
                  $item->type_file = '1';  
                    
                }
                
                
                if ($request->quize_link!=null) {
                $item->quize =  $request->quize_link;
                $item->start_time = $request->quize_start_time;
                $item->end_time = $request->quize_end_time;
                $item->type = '2';
                $item->type_file = '1'; 

                    }

                if ($request->test_link!=null) {
$item->test =  $request->test_link;
                $item->start_time = $request->test_start_time;
                $item->end_time = $request->test_end_time;
                $item->type = '1';
                $item->type_file = '1'; 
}

                if ($request->addition && $request->hasFile('addition')) {
                    $item->addition =  $request->addition->store('filesteachers', 'public');
                    $item->extension =  $request->addition->extension();
                    $item->type = '4';

                }
               if ($request->video) {
                        $item->video = $request->video;
                                    $item->type = '0';

                    }
                    
                    
                                       if ($request->video_in && $request->hasFile('video_in')) {
                $item->video = $request->video_in->store('filesteachers', 'public');
                                $item->type_video='0';

            }
            
            
                        if ($request->video!=null) {
                $item->video = $request->video;
                
                $item->type_video='1';
            }



                                                       if ($request->test_start_time) {
                        $item->start_time = $request->test_start_time;

                    }

                                   if ($request->test_end_time) {
                        $item->end_time = $request->test_end_time;

                    }
                    
                                                       if ($request->quize_start_time) {
                        $item->start_time = $request->quize_start_time;

                    }

                                   if ($request->quize_end_time) {
                        $item->end_time = $request->quize_end_time;

                    }
                    
                    
                    
                                   if ($request->exam_start_time) {
                        $item->start_time = $request->exam_start_time;

                    }

                                   if ($request->exam_end_time) {
                        $item->end_time = $request->exam_end_time;

                    }
                                                       if ($request->type) {
                        $item->type = $request->type;

                    }
                    
    $item->lesson_id=$request->lesson_id;


$item->save();
return redirect()->back()->with('success','! تمت العملية بنجاح ');


}

    public function teacher_lessons3($class_id){

                $year=Year::where('current_year','1')->first();

$lessons=Teacher::find(auth()->user()->teacher_id);
    $lessons=$lessons->lessons()->where('teacher_room_lesson.class_id',$class_id)->where('teacher_room_lesson.year_id',$year->id)->get()->unique();
    return $lessons;

    }

    public function rooms3($class_id){
                $year=Year::where('current_year','1')->first();

$lessons=Teacher::find(auth()->user()->teacher_id);
    $rooms=$lessons->rooms()->where('teacher_room_lesson.class_id',$class_id)->where('teacher_room_lesson.year_id',$year->id)->get()->unique();

        return $rooms;

    }
    
    public function event_edit($event_id) {
                        $year=Year::where('current_year','1')->first();

        $event=Teacher_event::find($event_id);
            $class_old=Room::find($event->room_id)->classes;

        $lessons=Teacher::find(auth()->user()->teacher_id);
    $rooms=$lessons->rooms()->where('teacher_room_lesson.class_id',$class_old->id)->where('teacher_room_lesson.year_id',$year->id)->get()->unique();
                $teacher=Teacher::find(auth()->user()->teacher_id);

        $classes=$teacher->classes->unique();


        return view('teachers.event_edit',compact('event','rooms','classes','teacher'));
        
        
        
        
    }

    public function event_update(Request $request,$event_id) {
        $year=Year::where('current_year','1')->first();

        $teacher_event=Teacher_event::find($event_id);
        $teacher_event->class_id = $request->class_id ;
        $teacher_event->room_id = $request->room_id ;
        $teacher_event->year_id = $year->id;
        $teacher_event->teacher_id = auth()->user()->teacher_id;
        $teacher_event->title = $request->title;
        $teacher_event->content = $request->content;
        $teacher_event->date = $request->date;

        $teacher_event->save();

        return redirect()->back()->with('success','! تمت العملية بنجاح ');

        
        
        
        
    }
}
