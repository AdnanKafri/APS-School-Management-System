<?php

namespace App\Http\Controllers;
use App\Invoice;

use App\Classe;
use App\Lesson;
use App\Lesson_teacher_room_term_exam;
use App\Room;
use App\Room_student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Message;
use App\Teacher_event;

use App\Student;
use App\Student_lesson_teacher_room_term_exam;
use App\Students_mark;
use App\Teacher_room_lesson;
use App\User;
use App\Year;
use Carbon\Carbon;
use DateTime;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use RealRashid\SweetAlert\Facades\Alert;
use Cartalyst\Stripe\Laravel\Facades\Stripe;

class studentscontroller extends Controller
{
    
        public function __construct()
    {
        $this->middleware(function($request,$next){
            if (session('success')) {
                Alert::success(session('success'));
            }

            if (session('warning')) {
                Alert::warning(session('warning'));
            }

            return $next($request);
        });
    }


    public function create(){

        return view('login_student');

    }



    public function dashboard(){

        $student_id=Auth::user()->student_id;

        $student=Student::find($student_id);
                $count=Message::whereNull('view')->where('student_id',auth()->user()->student_id)->get();

                $count=$count->count();
        $year=Year::where('current_year','1')->first();

$room=$student->room()->where('rooms.year_id',$year->id)->first();
$class=$room->classes;
        return view('students.dashboard',compact('student','count','room','class'));
    }



    public function update_profile(Request $request, $student_id){

        $student=Student::find($student_id);

        if ($request->image != null) {
            Storage::disk('public')->delete($student->image);
            $student->image=$request->image->store('filesstudents','public');
        }

        $student->save();
        return redirect()->back()->with('success','! تمت العملية بنجاح ');
    }



    public function update_password(Request $request,$student_id){

        // return $teacher_id;
        $user=User::find($student_id);
// return $user;

        $this->validate($request, [
            'old_password'          => 'required',
            'password'              => 'required|min:4',
            'password_confirmation' => 'required|same:password'
        ]);
        if (Hash::check($request->old_password, $user->password)) {

            $user->password = Hash::make($request->password);
            $user->view_password = $request->password;

            $user->save();

           }
           else{
            return redirect()->back()->with('warning','! كلمة المرور القديمة خاطئة');

           }


        return redirect()->back()->with('success','! تمت العملية بنجاح ');

    }




    public function lessons($student_id){
        $year=Year::where('current_year','1')->first();
        $student=Student::find($student_id);
        $item=Room_student::where('student_id',$student_id)->where('year_id',$year->id)->first();
                if ($item=="") {

            return redirect()->back();
        }
        $room=Room::with('classes')->where('id',$item->room_id)->first();
        $lessons= $room->teachers;
        // $l=Lesson::with('room','teachers')->where()
        $lessons=Room::with(['lessons'=>function($q){
            $q->with('teachers');
        }])->find($room->id);

if ($student->lang=='0' && $student->religion=='0') {

    $lessons=$lessons->lessons()->where(function ($query) {
        $query->where(function($q1){

            $q1->where('religion','<>','1');
            $q1->orwhere('religion',null);
            $q1->where('lang',null);

        });

        $query->orwhere(function($q2){

            $q2->where('lang','<>','1');

            $q2->orwhere('lang',null);
            $q2->where('religion',null);

        });



    }
    )->get();

}elseif($student->lang=='1' && $student->religion=='1'){

    $lessons=$lessons->lessons()->where(function ($query) {
        $query->where(function($q1){

            $q1->where('religion','<>','0');
            $q1->orwhere('religion',null);
            $q1->where('lang',null);

        });

        $query->orwhere(function($q2){

            $q2->where('lang','<>','0');

            $q2->orwhere('lang',null);
            $q2->where('religion',null);

        });



    }
    )->get();
}elseif($student->religion=='0' && $student->lang=='1'){

    $lessons=$lessons->lessons()->where(function ($query) {
        $query->where(function($q1){

            $q1->where('religion','<>','1');
            $q1->orwhere('religion',null);
            $q1->where('lang',null);

        });

        $query->orwhere(function($q2){

            $q2->where('lang','<>','0');

            $q2->orwhere('lang',null);
            $q2->where('religion',null);

        });



    }
    )->get();
}
elseif($student->religion=='1' && $student->lang=='0'){


    $lessons=$lessons->lessons()->where(function ($query) {
        $query->where(function($q1){

            $q1->where('religion','<>','0');
            $q1->orwhere('religion',null);
            $q1->where('lang',null);

        });

        $query->orwhere(function($q2){

            $q2->where('lang','<>','1');

            $q2->orwhere('lang',null);
            $q2->where('religion',null);

        });



    }
    )->get();

}

                $count=Message::whereNull('view')->where('student_id',auth()->user()->student_id)->get();

                $count=$count->count();
                
                

$class=$room->classes;

        return view('students.lessons',compact('room','count','lessons','student','class'));
    }






    public function lesson_detail($lesson_id,$student_id){

        $year=Year::where('current_year','1')->first();

        $student=Student::with(['room'=>fn($q1)=>$q1->where('rooms.year_id',$year->id)])->find($student_id);
        $lesson=Lesson::find($lesson_id);

        $room_id= $student->room[0]->id;
        $date = new DateTime();
        $now=$date->format('Y-m-d H:i:s');
    
    $now=Carbon::now();

       $lesson_details=Lesson_teacher_room_term_exam::where('lesson_id',$lesson_id)
       ->where('room_id',$room_id)->orderBy("id",'desc')->get();

        $teacher_room_lesson=Teacher_room_lesson::where('room_id',$room_id)->where('lesson_id',$lesson_id)->get();

        $teacher_id=$teacher_room_lesson[0]->teacher_id;

        $term_id=Lesson_teacher_room_term_exam::where('lesson_id',$lesson_id)
        ->where('teacher_id',$teacher_id)->get();


            if ($term_id->count()!=0) {
                $term_id= $term_id[0]->term_id;
            }


            $student_mark=Students_mark::where('student_id',$student->id)->where('year_id',$year->id)->where('room_id',$room_id)->first();

            $answers=[];
            $available_lesson_detail=Lesson_teacher_room_term_exam::where('lesson_id',$lesson_id)
            ->where('room_id',$room_id)->where('start_time','<=',$now)->where('end_time','>=',$now)->get();

            // return $available_lesson_detail;
            foreach ($available_lesson_detail as $item) {

                $answers[]=Student_lesson_teacher_room_term_exam::where('student_id',$student_id)
                ->where('file_id',$item->id)->get();
            }


                $count=Message::whereNull('view')->where('student_id',auth()->user()->student_id)->get();

                $count=$count->count();

        $year=Year::where('current_year','1')->first();

$room=$student->room()->where('rooms.year_id',$year->id)->first();
$class=$room->classes;

$mark_status=Teacher_room_lesson::where('lesson_id',$lesson_id)->where('room_id',$room->id)->where('year_id',$year->id)->where('teacher_id',$teacher_id)->first();
 
 $time_status=[];
 
 foreach($lesson_details as $item) {
     
     $time_status[$item->id]= Carbon::now()->lte($item->end_time);
 }
 



    return view('students.lesson_detail',compact('now','time_status','mark_status','room','class','student','answers','lesson','lesson_details','lesson_id','count','student_id','teacher_id','room_id','term_id','student_mark'));

    }


    public function results($student_id){

   
        $year=Year::where('current_year','1')->first();

        $student=Student::with(['room'=>fn($q1)=>$q1->where('room_student.year_id',$year->id)])->find($student_id);
        $room=$student->room;
        if ($room->isEmpty() || $student->status!='1') {
            return redirect()->back()->with('warning','لم تصدر النتائج بعد !');

        }
        $student_mark=null;
        if ($student->status!=0) {
            $student_mark=Students_mark::where('student_id',$student_id)
            ->where('room_id',$room[0]->id)->where('year_id',$year->id)->first();
        }

        $lessons=  $room[0]->classes->lessons;

                $count=Message::whereNull('view')->where('student_id',auth()->user()->student_id)->get();

                $count=$count->count();


$room=$student->room()->where('rooms.year_id',$year->id)->first();
$class=$room->classes;
        return view('students.results',compact('student_mark','student','class','room','count','lessons'));



    }

    public function upload_store(Request $request){


        // return $request->all();
//         $extension = $request->exam_file->extension();
// return $extension;
// $date = new DateTime();
// $now=$date->format('Y-m-d H:i:s');
$now=Carbon::now();
// return $now;

// return $question;

$question=Lesson_teacher_room_term_exam::find($request->file_id);

if ($now>$question->start_time && $now<$question->end_time) {
    $answer=Student_lesson_teacher_room_term_exam::where('file_id',$request->file_id)->
    where('student_id',$request->student_id)->where('type',$request->type)->first();

    if ($answer) {
    return redirect()->back()->with('warning','يجب حذف الملف السابق اولا ');
    }
    $item=new Student_lesson_teacher_room_term_exam;
    $item->student_id=$request->student_id;
    $item->lesson_id=$request->lesson_id;
    $item->teacher_id=$request->teacher_id;
    $item->student_id=$request->student_id;
    $item->room_id=$request->room_id;
    $item->term_id=$request->term_id;
    $item->file_id=$request->file_id;

    if ($request->hasFile('test_file')) {
        $item->type='1';

        $item->file=$request->test_file->store('filesstudents','public');
        $item->extension  = $request->test_file->extension();

    }


    if ($request->hasFile('quize_file')) {
        $item->type='2';

        $item->file=$request->quize_file->store('filesstudents','public');

        $item->extension  = $request->quize_file->extension();

    }

    if ($request->hasFile('exam_file')) {
        $item->type='3';

        $item->file=$request->exam_file->store('filesstudents','public');

        $item->extension = $request->exam_file->extension();

    }

    $item->save();

    return redirect()->back()->with('success','! تمت العملية بنجاح ');


}

        return redirect()->back()->with('Warning','عذرا انتهى وقت الامتحان');

    }

    public function delete_answer($id,$student_id,$file_id,$type){

        $answer=Student_lesson_teacher_room_term_exam::find($id);
        Storage::disk('public')->delete($answer->file);

        $answer->delete();

        return redirect()->back()->with('success','! تمت العملية بنجاح ');



    }

    public function delete_answer2(Request $request){

        $answer=Student_lesson_teacher_room_term_exam::find($request->id);
        Storage::disk('public')->delete($answer->file);

        $answer->delete();

        return response()->json([
            'status' => true ,
            'msg'=> 'تم الحذف بنجاح ' ,

        ]);
        // return redirect()->back()->with('success','تم حذف الملف بنجاح !');



    }
    
    
    
    public function financial_account($student_id) {

        $year=Year::where('current_year','1')->first();
        $student = Student::with(['room'=>fn($q1)=>$q1->where('room_student.year_id',$year->id)])->find($student_id);
        $class=$student->room[0]->classes;

        $invoices= Invoice::where('student_id',$student_id)->where('class_id',$class->id)->where('year_id',$year->id)->get();





        $class=Classe::find($class->id);
        $year=Year::where('current_year','1')->first();

                $remain_amount=0;
                $full_amount = $class->annual_installment;
                $amount_paid = 0;
                foreach ($invoices as $item) {
                    $amount_paid=$amount_paid + $item->invoice_amount;

                }

                $remain_amount = $full_amount - $amount_paid;


          $count=Message::whereNull('view')->where('student_id',auth()->user()->student_id)->get();

                $count=$count->count();


$room=$student->room()->where('rooms.year_id',$year->id)->first();
$class=$room->classes;
        return view('students.financial_account',compact('invoices','student','class','room','count','remain_amount','amount_paid','full_amount'));

    }
    
    
    

    public function messages($student_id) {
        $year=Year::where('current_year','1')->first();

        $student=Student::find($student_id);

        $messages=Message::where('student_id',$student->id)->where('year_id',$year->id)->get();

        foreach ($messages as $item) {

           $m=Message::find($item->id);
           $m->view='1';
            $m->save();
        }
        
        
$room=$student->room()->where('rooms.year_id',$year->id)->first();
$class=$room->classes;

        return view('students.messages',compact('student','class','room','messages'));
    }
    
    
        public function events() {

        $year=Year::where('current_year','1')->first();

        $student = Student :: find(auth()->user()->student_id);

        $room= $student->room->where('year_id',$year->id);
        if($room->isEmpty()) {
            
            return redirect()->back();
        }

        $events=Teacher_event::where('year_id',$year->id)->where('room_id',$room[0]->id)->
        whereDate('date', '>=', Carbon::today()->toDateString())->get();

        
$room=$student->room()->where('rooms.year_id',$year->id)->first();
$class=$room->classes;
        return view('students.events',compact('events','student','class','room'));

    }
    
public function checkout(Request $request)  {
        $amount=$request->amount;
        $student = Student :: find(auth()->user()->student_id);

        $count=Message::whereNull('view')->where('student_id',auth()->user()->student_id)->get();
        $count=$count->count();
        
                $year=Year::where('current_year','1')->first();

$room=$student->room()->where('rooms.year_id',$year->id)->first();
$class=$room->classes;
        return view('students.checkout',compact('amount','student','class','room','count'));

    }

    public function charge(Request $request){
          $year=Year::where('current_year','1')->first();

  
 $charge=Stripe::charges()->create([

    'amount' => $request->amount,
    'currency' => 'usd',
    'description' => 'Example charge',
    'source' => $request->stripeToken,
]);

$student=Student::find(auth()->user()->student_id);
$room=$student->room()->where('rooms.year_id',$year->id)->first();
$class=$room->classes;
 $chargeId=$charge['id'];
if ($chargeId) {

 $invoice=new Invoice;
$invoice->student_id = $student->id;
$invoice->class_id=$class->id;
$invoice->year_id=$year->id;
$invoice->invoice_amount=$request->amount;

$invoice->save();   
return redirect()->route('dashboard')->with('success','! تمت العملية بنجاح');

}
    }
    
}
